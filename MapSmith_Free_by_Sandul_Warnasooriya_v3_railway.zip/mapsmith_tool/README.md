<h1 align="center">MapSmith Free 🗺️⛏️</h1>

<p align="center">
  <b>Turn real-world maps into playable Minecraft worlds — for free.</b><br>
  <i>by <b>Sandul Warnasooriya</b> · built with <a href="https://arena.ai">Arena.ai</a></i>
</p>

<p align="center">
  <img alt="License: MIT" src="https://img.shields.io/badge/license-MIT-blue.svg">
  <img alt="Python" src="https://img.shields.io/badge/python-3.10%2B-blue.svg">
  <img alt="Minecraft" src="https://img.shields.io/badge/Minecraft-Java%20%2B%20Bedrock-green.svg">
  <img alt="Status" src="https://img.shields.io/badge/status-active-success.svg">
</p>

A self-hosted, open-source alternative to paid "real map → Minecraft" tools.
Draw an area on a map, set a spawn point, choose Java or Bedrock, and get a
ready-to-play Minecraft world built from **real OpenStreetMap data and real
elevation**.

No accounts. No fees. No API keys. Runs on your machine — or deploy it to the
web so anyone can use it.

### 🚀 One-click deploy

<p>
  <a href="https://render.com/deploy"><img alt="Deploy to Render" src="https://render.com/images/deploy-to-render-button.svg"></a>
  &nbsp;
  <a href="https://railway.app/new"><img alt="Deploy on Railway" src="https://railway.app/button.svg"></a>
</p>

> After connecting your GitHub repo to the host, **every `git push` auto-deploys**.
> 📖 Full step-by-step guides: **[GitHub + Railway](DEPLOY_RAILWAY.md)** (recommended) · [all hosts](DEPLOY.md).
> _(Note: GitHub **Pages** can't run this — it needs a Python backend. Use a host like Render/Railway/Fly, connected to your GitHub repo.)_

### 📸 Previews

| 3D isometric view | Top-down map |
|---|---|
| ![3D preview](docs/images/preview-3d.png) | ![Top-down preview](docs/images/preview-topdown.png) |

*The 3D view shows real terrain relief, raised buildings, roads and the solid
ground depth. The red marker is your spawn point.*

---

## ✨ What it does

It converts real-world data into Minecraft blocks:

| Real world | In Minecraft |
|------------|--------------|
| Elevation / terrain | Sculpted land height (stone + dirt + grass) |
| Rivers, lakes, sea | Water |
| Roads & streets | Gray-concrete roads (width by road class) |
| Footpaths & tracks | Grass paths |
| Buildings | Extruded block structures (height from OSM levels/height) |
| Forests / woods | Grass + scattered oak trees |
| Farmland | Farmland blocks |
| Parks / grass / meadow | Grass |
| Beaches / sand | Sand |
| Railways | Stone rail beds |

> Generation detail depends on how well the area is mapped on
> [OpenStreetMap](https://www.openstreetmap.org). Well-mapped cities look great;
> remote areas will mostly be terrain.

### Plus
- **🖼️ Live previews (2D + 3D)** — before committing to a full build, render a
  top-down map **and** a 3D isometric view that shows real terrain relief,
  raised buildings and the spawn marker.
- **🐮 Mobs & villagers** — animals and professional villagers are placed
  (climate-appropriate: rabbits in deserts, polar bears in snow, parrots in
  jungles, etc.) and written directly into the world.
- **🏮 Structures** — street lamps along roads, wells, market stalls, park
  benches, and scarecrows in farmland.
- **🌍 Biome-accurate palettes** — pick a theme (or **Auto** from latitude):
  Plains, Forest, Desert, Snowy, Jungle, Savanna, Swamp. Each swaps ground,
  trees and building materials **and** writes the proper per-chunk `Biomes`
  array so grass/water/foliage tints render correctly in-game.
- **🏠 Building interiors** — buildings are hollow with wooden floors, windows,
  doorways, ceiling lights and furniture (beds, crafting tables, furnaces,
  chests, bookshelves, rugs).
- **🛤️ Village paths** — short grass-path spurs connect building doorways to the
  nearest street.
- **🪨 Built-in Bedrock `.mcworld` export (beta)** — generate a Bedrock world
  directly (LevelDB), no external converter needed. (A converter fallback is
  documented for game builds that reject the beta output.)

---

## 🚀 Quick start

### 1. Install dependencies

```bash
cd mapsmith_tool
pip install -r requirements.txt
```

### 2a. Run the web app (recommended)

```bash
python app.py
```

Open **http://127.0.0.1:5000** in your browser, then:

1. **Search** for a place (or pan/zoom the map).
2. Click **▭ Draw area** and drag a rectangle over the area you want.
3. Click **⊹ Set spawn** and click where you want to spawn (optional — defaults to centre).
4. Pick **World name**, **Edition** (Java / Bedrock / Both), and scale options.
5. Click **⚒ BUILD MY WORLD**, watch the live log, then **⬇ Download**.

### 2b. Or use the command line

```bash
# By bounding box: south west north east
python cli.py --bbox 7.000 80.600 7.0027 80.6027 --name "MyTown" --edition both

# By centre + radius (metres)
python cli.py --center 7.0013 80.6013 --radius 400 --name "MyTown"
```

Worlds are written to `./output/<name>/` plus a zipped `./output/<name>_java.zip`.

---

## 🎮 Installing the world in Minecraft

### Java Edition
1. Unzip the downloaded `*_java.zip`.
2. Move the resulting folder into your saves directory:
   - **Windows:** `%appdata%\.minecraft\saves\`
   - **macOS:** `~/Library/Application Support/minecraft/saves/`
   - **Linux:** `~/.minecraft/saves/`
3. Launch Minecraft (1.16.5 or newer — newer versions auto-upgrade the world) and play.

### Bedrock Edition
When you choose **Bedrock** or **Both**, MapSmith now also writes a Bedrock
`.mcworld` file directly (beta). Just open/import it in Minecraft Bedrock.

If your specific game build rejects the beta `.mcworld`, use the always-reliable
free converter route instead:
1. Get the Java `.zip` from MapSmith.
2. Open it in a **free converter**:
   - [Chunker](https://chunker.app) (browser-based, free), or
   - [Amulet Editor](https://www.amuletmc.com) (free desktop app).
3. Export as **Bedrock** → import the resulting `.mcworld` into Minecraft Bedrock.

---

## ⚙️ Options

| Option | Meaning |
|--------|---------|
| **Scale (blocks/metre)** | `1` = true to life. `0.5` = smaller/faster. `2` = bigger/more detail. |
| **Terrain exaggeration** | Multiplies height differences. `1` realistic, `2` dramatic hills, `0.5` flatter. |
| **Elevation detail** | Resolution of the elevation grid sampled from the web. |
| **Biome theme** | `auto` (guess from latitude) or one of plains/forest/desert/snowy/jungle/savanna/swamp. |
| **Mobs & villagers** | Toggle placement of animals + villagers. |
| **Structures** | Toggle lamps/wells/stalls/benches/scarecrows. |
| **Edition** | `java`, `bedrock` (conversion note), or `both`. |

CLI flags mirror these: `--theme`, `--no-mobs`, `--no-structures`,
`--preview-only` (render just the PNG, no world build).

**Area limit:** each side is capped at ~5 km, and the world is auto-scaled if it
would exceed 1024 blocks per side, to keep generation fast and memory-friendly.

---

## 🧩 How it works

```
   ┌──────────────┐   ┌──────────────────┐   ┌────────────────┐
   │  Your bbox   │──▶│ OpenStreetMap     │──▶│ Rasterise to a │
   │  + spawn     │   │ (Overpass API)    │   │ block grid     │
   └──────────────┘   │ Open-Elevation    │   │ (roads,water,  │
                      └──────────────────┘   │  buildings...) │
                                              └───────┬────────┘
                                                      ▼
                                       ┌──────────────────────────┐
                                       │ Build heightmap + place   │
                                       │ blocks → Anvil region     │
                                       │ files + level.dat → .zip  │
                                       └──────────────────────────┘
```

### Project layout
```
mapsmith_tool/
├── app.py                 # Flask web app (UI + API)
├── cli.py                 # command-line interface
├── requirements.txt
├── templates/index.html   # the web UI (Leaflet map)
├── mapsmith/
│   ├── geo.py             # bbox + lat/lon → block projection
│   ├── datasources.py     # Overpass + elevation fetch (cached, retrying)
│   ├── terrain.py         # heightmap + OSM rasteriser
│   ├── blocks.py          # block palette + biome themes
│   ├── mcchunk.py         # chunk subclass writing Biomes + Entities
│   ├── preview.py         # top-down 2D PNG renderer
│   ├── worldbuilder.py    # blocks + structures + mobs + level.dat + zip
│   └── pipeline.py        # orchestrates everything
├── static/previews/       # generated preview PNGs
├── cache/                 # cached OSM/elevation responses
└── output/                # generated worlds + zips
```

---

## 🛠️ Troubleshooting

- **"OpenStreetMap (Overpass) is rate-limiting"** — the free public Overpass
  servers throttle heavy use. Wait a minute and try again, or pick a smaller
  area. Successful fetches are cached locally, so retries are instant.
- **Flat/empty world** — the area is sparsely mapped on OSM, or elevation was
  unavailable (falls back to flat terrain). Try a town or city.
- **World looks low/high** — adjust *Terrain exaggeration*.
- **Terrain feels flat in some spots** — that's the real-world elevation; many
  towns genuinely are flat. Hilly areas get full relief. The ground is always
  solid underground (filled `TERRAIN_DEPTH` blocks deep, default 40), so you can
  dig down without hitting void.

---

## 🌐 Deploy to the web (so anyone can use it)

The repo ships with a `Dockerfile` (includes LevelDB for Bedrock export) and
configs for the popular free/cheap hosts. Pick one:

### Option A — Render.com (easiest, free tier)
1. Push this repo to GitHub.
2. Go to [render.com](https://render.com) → **New** → **Blueprint** → connect
   your repo. Render reads `render.yaml` and builds the Docker image.
3. Wait for the build; your app is live at `https://<name>.onrender.com`.

### Option B — Railway  ⭐ (full step-by-step: [DEPLOY_RAILWAY.md](DEPLOY_RAILWAY.md))
1. [railway.app](https://railway.app) → sign in with GitHub → **New Project → Deploy from GitHub repo** → pick your repo.
2. Railway auto-detects the `Dockerfile` + `railway.json` and builds (incl. LevelDB for Bedrock).
3. Service → **Settings → Networking → Generate Domain** → live at `https://<name>.up.railway.app`.
4. Every `git push` auto-redeploys.

### Option C — Fly.io (global, generous free allowance)
```bash
brew install flyctl          # or: curl -L https://fly.io/install.sh | sh
fly auth login
fly launch --copy-config --no-deploy   # edit app name if prompted
fly deploy
```

### Option D — any Docker host / your own VPS
```bash
docker build -t mapsmith-free .
docker run -p 8000:8000 mapsmith-free
# open http://localhost:8000
```

> **Heads-up for hosting:** world generation is CPU/RAM-heavy (≈1 GB peak).
> Use an instance with at least **1 GB RAM**. Free tiers work for small areas;
> larger areas may need a paid instance. The public OpenStreetMap/Overpass API
> rate-limits heavy use — for a busy public deployment, consider running your
> own Overpass instance or adding request throttling.

---

## 📜 Credits & licence

**Created by Sandul Warnasooriya.**
**Built with [Arena.ai](https://arena.ai).**

- Map data © **OpenStreetMap** contributors, [ODbL](https://www.openstreetmap.org/copyright).
- Elevation via **Open-Elevation** (open data).
- Built with Flask, Leaflet, NumPy, Pillow, `plyvel`/LevelDB (Bedrock export),
  and the `anvil-new` / `NBT` Python libraries.

Licensed under the **MIT License** (see [`LICENSE`](LICENSE)). Free for personal
and commercial use. Please respect the usage policies of the free public APIs it
relies on.

© Sandul Warnasooriya. Generated worlds are tagged with the author in their
`level.dat`.
