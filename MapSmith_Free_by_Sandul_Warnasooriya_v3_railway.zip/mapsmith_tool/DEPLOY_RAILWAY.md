# Deploy MapSmith Free with GitHub + Railway 🚂

by Sandul Warnasooriya · built with [Arena.ai](https://arena.ai)

This deploys the **full app** (Java + Bedrock export, 2D/3D previews, visitor
log) to the public web. Railway builds straight from your GitHub repo and
re-deploys automatically on every `git push`.

---

## Step 1 — Put the code on GitHub

From inside the `mapsmith_tool` folder (it's already a git repo):

```bash
git remote add origin https://github.com/<your-username>/mapsmith-free.git
git branch -M main
git push -u origin main
```

(If you downloaded the zip, unzip it, `cd mapsmith_tool`, then run
`git init && git add -A && git commit -m "MapSmith Free"` before the commands
above.)

---

## Step 2 — Create the Railway project

1. Go to **[railway.app](https://railway.app)** and sign in **with GitHub**.
2. Click **New Project → Deploy from GitHub repo**.
3. Pick your **`mapsmith-free`** repo and confirm.
4. Railway detects the **`Dockerfile`** and `railway.json` and starts building.
   (The Dockerfile installs LevelDB so Bedrock `.mcworld` export works.)

The first build takes a few minutes (it compiles `plyvel`). When it finishes
you'll see a green "Active" deploy.

---

## Step 3 — Get a public URL

1. Open your service → **Settings → Networking**.
2. Click **Generate Domain**.
3. Railway gives you `https://<name>.up.railway.app` — share that with anyone. 🎉

> The app reads Railway's injected `$PORT` automatically — you don't set it.

---

## Step 4 — (Optional) configure variables

Service → **Variables** tab → add any of these:

| Variable | Suggested value | Purpose |
|---|---|---|
| `MAPSMITH_MAX_BLOCKS` | `128` (free) / `256` (≥1 GB) / `512` (≥2 GB) | World-size cap; bigger = more RAM |
| `MAPSMITH_ADMIN_TOKEN` | `your-secret` | Password-protects `/admin/visitors` |

The Dockerfile already defaults `MAPSMITH_MAX_BLOCKS=128`, so it runs safely on
the free tier without any variables set.

---

## After deploy

- **App:** `https://<name>.up.railway.app`
- **Visitor dashboard:** `https://<name>.up.railway.app/admin/visitors`
  (add `?token=your-secret` if you set `MAPSMITH_ADMIN_TOKEN`)
- **Every `git push`** to `main` auto-rebuilds and redeploys.

---

## Plan & cost notes ⚠️

- Railway's **free trial** gives ~$5 credit / **0.5 GB RAM** per service. That's
  enough for MapSmith in the default lite mode (128 blocks/side).
- After the trial, the **Hobby plan ($5/mo)** gives much more RAM — set
  `MAPSMITH_MAX_BLOCKS=256` or higher there for bigger worlds.
- World generation is CPU/RAM-heavy and runs for 10–60 s; the start command uses
  a 600 s timeout so requests don't get cut off.
- The free public OpenStreetMap/Overpass API rate-limits heavy traffic. For a
  busy public site, add throttling or run your own Overpass instance
  (`OVERPASS_ENDPOINTS` in `mapsmith/datasources.py`).
- Generated worlds and the visitor log live on the container's ephemeral disk
  and reset on redeploy — fine, since users download immediately. Add a Railway
  **Volume** mounted at `/app/output` (and `/app/logs`) if you want persistence.

---

## Troubleshooting

| Problem | Fix |
|---|---|
| Build fails on `plyvel` | Make sure Railway is using the **Dockerfile** builder (it is by default via `railway.json`). |
| App "crashed" / OOM | Lower `MAPSMITH_MAX_BLOCKS` to `96`, or upgrade the plan. |
| Blank page over `https` | That's fine — Railway gives real HTTPS. If you used a raw IP:port elsewhere, use the generated domain. |
| 502 right after deploy | Wait ~30 s for the worker to boot; health check path is `/`. |
