#!/usr/bin/env bash
# MapSmith Free — startup for game-panel / low-RAM hosts (lunes.host, Pterodactyl)
# by Sandul Warnasooriya · built with Arena.ai
#
# The panel sets $SERVER_PORT (or $PORT). We default the world-size cap low so
# it fits in ~512 MiB of RAM. Override MAPSMITH_MAX_BLOCKS if you have more.
set -e
cd "$(dirname "$0")"

# Pick the port the panel assigned (lunes.host uses SERVER_PORT).
export PORT="${PORT:-${SERVER_PORT:-5000}}"
export HOST="0.0.0.0"

# Memory-safe default for 512 MiB containers (~214 MB peak). Raise on bigger plans.
export MAPSMITH_MAX_BLOCKS="${MAPSMITH_MAX_BLOCKS:-128}"

echo "Installing dependencies (first run)…"
pip install --user -q -r requirements.txt || pip install -q -r requirements.txt

echo "Starting MapSmith Free on 0.0.0.0:${PORT} (max ${MAPSMITH_MAX_BLOCKS} blocks/side)…"
exec python app.py
