#!/usr/bin/env bash
# MapSmith Free — one-command launcher (installs deps + starts the web app)
set -e
cd "$(dirname "$0")"

echo "==> Installing dependencies (first run only)..."
pip install -q -r requirements.txt

echo "==> Starting MapSmith Free at http://127.0.0.1:5000"
python app.py
