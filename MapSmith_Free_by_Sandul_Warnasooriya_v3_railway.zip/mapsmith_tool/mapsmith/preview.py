"""Render preview PNGs of the generated world (2D top-down + 3D isometric).

Author: Sandul Warnasooriya
Built with: Arena.ai (https://arena.ai)
"""

from __future__ import annotations

import numpy as np
from PIL import Image

from .terrain import (
    BUILDING, FARM, FOREST, GRASS, LAND, RAIL, ROAD, SAND, WATER, PATH,
)

# base colours per feature (RGB)
FEATURE_COLOR = {
    LAND: (124, 175, 90),
    GRASS: (134, 188, 96),
    WATER: (74, 130, 200),
    ROAD: (90, 92, 98),
    PATH: (181, 158, 110),
    BUILDING: (200, 120, 90),
    FOREST: (62, 122, 64),
    FARM: (205, 178, 96),
    SAND: (224, 208, 152),
    RAIL: (110, 110, 110),
}

# theme tints applied to ground/sand so previews match the chosen climate
THEME_TINT = {
    "desert": {LAND: (224, 208, 152), GRASS: (214, 198, 140), FOREST: (170, 170, 110)},
    "snowy": {LAND: (236, 240, 245), GRASS: (228, 234, 240), FOREST: (200, 215, 210),
              FARM: (220, 225, 230)},
    "savanna": {LAND: (178, 178, 96), GRASS: (190, 186, 100), FOREST: (140, 150, 70)},
    "jungle": {LAND: (78, 150, 70), GRASS: (74, 158, 72), FOREST: (40, 110, 48)},
    "swamp": {LAND: (104, 138, 96), GRASS: (110, 142, 100), WATER: (90, 120, 110)},
}


def render_preview(surface, heights, theme_key, spawn_xz, out_path, max_px=900):
    """Render surface+heights to a PNG. Returns (path, w, h)."""
    d, w = surface.shape
    tint = THEME_TINT.get(theme_key, {})

    img = np.zeros((d, w, 3), dtype=np.uint8)
    for code, col in FEATURE_COLOR.items():
        col = tint.get(code, col)
        mask = surface == code
        img[mask] = col

    # hill shading from heights (simple gradient-based)
    h = heights.astype(np.float64)
    gz, gx = np.gradient(h)
    shade = np.clip(0.5 - (gx * 0.12 + gz * 0.12), 0.0, 1.0)
    # also brighten higher ground a touch
    if h.max() > h.min():
        elev = (h - h.min()) / (h.max() - h.min())
    else:
        elev = np.zeros_like(h)
    factor = (0.7 + 0.6 * shade + 0.15 * elev)[:, :, None]
    water_mask = (surface == WATER)
    out = np.clip(img * factor, 0, 255).astype(np.uint8)
    out[water_mask] = img[water_mask]  # keep water flat-coloured

    pil = Image.fromarray(out, "RGB")

    # mark spawn with a small red cross
    sx, sz = spawn_xz
    px = pil.load()
    for dd in range(-4, 5):
        for (ax, az) in ((sx + dd, sz), (sx, sz + dd)):
            if 0 <= ax < w and 0 <= az < d:
                px[ax, az] = (255, 40, 40)

    # upscale/downscale to a reasonable preview size (nearest = crisp pixels)
    scale = min(max_px / max(w, d), 4.0)
    if scale != 1.0:
        nw, nh = max(1, int(w * scale)), max(1, int(d * scale))
        pil = pil.resize((nw, nh), Image.NEAREST)

    pil.save(out_path)
    return out_path, pil.width, pil.height


def _shade(rgb, f):
    return tuple(int(max(0, min(255, c * f))) for c in rgb)


def render_iso_preview(surface, heights, bld_height, theme_key, spawn_xz,
                       out_path, max_cells=200):
    """Render a 3D isometric preview that shows real terrain relief + buildings.

    Each map cell is drawn as a small cube whose top sits at its surface height
    (elevation + building height). Far cells are drawn first (painter's order)
    so nearer/taller geometry overlaps correctly. Returns (path, w, h).
    """
    from PIL import ImageDraw

    d, w = surface.shape
    tint = THEME_TINT.get(theme_key, {})

    # Downsample to keep the drawing fast and the cubes visible.
    step = max(1, int(max(w, d) / max_cells))
    gw = (w + step - 1) // step
    gd = (d + step - 1) // step

    # Build downsampled colour + height grids.
    col_grid = [[None] * gw for _ in range(gd)]
    top_grid = [[0] * gw for _ in range(gd)]
    for gz in range(gd):
        for gx in range(gw):
            x = min(w - 1, gx * step)
            z = min(d - 1, gz * step)
            code = int(surface[z, x])
            base = FEATURE_COLOR.get(code, (124, 175, 90))
            base = tint.get(code, base)
            col_grid[gz][gx] = base
            h = int(heights[z, x])
            if code == BUILDING:
                h += int(bld_height[z, x])
            top_grid[gz][gx] = h

    # Isometric tile size.
    tw, th = 16, 8           # tile width/height (diamond)
    ez = 4                   # vertical pixels per block of height

    hmin = min(min(r) for r in top_grid)
    hmax = max(max(r) for r in top_grid)
    hrange = max(1, hmax - hmin)

    # Canvas size.
    pad = 40
    cw = int((gw + gd) * (tw / 2)) + pad * 2
    ch = int((gw + gd) * (th / 2) + hrange * ez + tw) + pad * 2
    img = Image.new("RGB", (cw, ch), (28, 31, 38))
    drw = ImageDraw.Draw(img)

    ox = pad + int(gd * (tw / 2))
    oy = pad + hrange * ez

    sx, sz = spawn_xz
    sgx, sgz = sx // step, sz // step

    def project(gx, gz, h):
        px = ox + int((gx - gz) * (tw / 2))
        py = oy + int((gx + gz) * (th / 2)) - int((h - hmin) * ez)
        return px, py

    # Painter's order: back (low gx+gz) to front (high gx+gz).
    for s in range(gw + gd - 1):
        for gx in range(gw):
            gz = s - gx
            if gz < 0 or gz >= gd:
                continue
            base = col_grid[gz][gx]
            h = top_grid[gz][gx]
            tx, ty = project(gx, gz, h)
            # top diamond
            top = [(tx, ty - th // 2), (tx + tw // 2, ty),
                   (tx, ty + th // 2), (tx - tw // 2, ty)]
            # left & right faces go down to the floor of the view
            floor = oy + int((gx + gz) * (th / 2)) - int((0) * ez) + 60
            left = [(tx - tw // 2, ty), (tx, ty + th // 2),
                    (tx, floor + th // 2), (tx - tw // 2, floor)]
            right = [(tx + tw // 2, ty), (tx, ty + th // 2),
                     (tx, floor + th // 2), (tx + tw // 2, floor)]
            drw.polygon(left, fill=_shade(base, 0.6))
            drw.polygon(right, fill=_shade(base, 0.8))
            drw.polygon(top, fill=_shade(base, 1.0), outline=_shade(base, 0.5))
            # spawn marker
            if gx == sgx and gz == sgz:
                drw.polygon(top, fill=(255, 60, 60), outline=(120, 0, 0))

    # cap to a sensible width
    if img.width > 1100:
        scale = 1100 / img.width
        img = img.resize((int(img.width * scale), int(img.height * scale)),
                         Image.LANCZOS)
    img.save(out_path)
    return out_path, img.width, img.height
