"""Fetch real-world data: OpenStreetMap (Overpass API) and elevation.

All data sources used here are free and require no API key:

* OpenStreetMap via the public Overpass API mirrors.
* Elevation via the Open-Elevation API (free, public).

Results are cached on disk so repeated runs of the same area are fast and kind
to the public servers.

Author: Sandul Warnasooriya
Built with: Arena.ai (https://arena.ai)
"""

from __future__ import annotations

import hashlib
import json
import os
import time

import requests

from .geo import BBox

CACHE_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "cache")
os.makedirs(CACHE_DIR, exist_ok=True)

USER_AGENT = "MapSmithFree/1.0 (https://github.com/ - free OSM->Minecraft tool)"

OVERPASS_ENDPOINTS = [
    "https://overpass-api.de/api/interpreter",
    "https://overpass.kumi.systems/api/interpreter",
    "https://maps.mail.ru/osm/tools/overpass/api/interpreter",
]

ELEVATION_ENDPOINTS = [
    "https://api.open-elevation.com/api/v1/lookup",
]


def _cache_path(key: str) -> str:
    h = hashlib.sha1(key.encode()).hexdigest()[:16]
    return os.path.join(CACHE_DIR, f"{h}.json")


def _cached(key: str):
    p = _cache_path(key)
    if os.path.exists(p):
        try:
            with open(p, "r") as f:
                return json.load(f)
        except Exception:
            return None
    return None


def _store(key: str, data) -> None:
    try:
        with open(_cache_path(key), "w") as f:
            json.dump(data, f)
    except Exception:
        pass


# --------------------------------------------------------------------------- #
# OpenStreetMap
# --------------------------------------------------------------------------- #
def fetch_osm(bbox: BBox, log=print) -> dict:
    """Fetch buildings, roads, water and landuse for a bbox via Overpass."""
    key = "osm:" + bbox.overpass_str()
    cached = _cached(key)
    if cached is not None:
        log("Using cached OSM data.")
        return cached

    b = bbox.overpass_str()
    query = f"""
    [out:json][timeout:60];
    (
      way["building"]({b});
      relation["building"]({b});
      way["highway"]({b});
      way["waterway"]({b});
      way["natural"="water"]({b});
      relation["natural"="water"]({b});
      way["landuse"]({b});
      way["natural"]({b});
      way["leisure"]({b});
      way["railway"]({b});
    );
    out geom;
    """
    headers = {"User-Agent": USER_AGENT}
    last_err = None
    # Try each endpoint, with a couple of retries to ride out rate limits.
    for attempt in range(3):
        for url in OVERPASS_ENDPOINTS:
            try:
                log(f"Querying OpenStreetMap ({url.split('/')[2]}) ...")
                r = requests.post(url, data={"data": query}, headers=headers, timeout=90)
                if r.status_code == 200:
                    data = r.json()
                    log(f"OSM returned {len(data.get('elements', []))} elements.")
                    _store(key, data)
                    return data
                last_err = f"HTTP {r.status_code}"
                if r.status_code in (429, 403, 504):
                    log(f"  {url.split('/')[2]} busy/rate-limited ({r.status_code}).")
            except Exception as e:  # noqa: BLE001
                last_err = str(e)
                log(f"  endpoint failed: {last_err}")
            time.sleep(2)
        if attempt < 2:
            wait = 8 * (attempt + 1)
            log(f"All endpoints busy; waiting {wait}s before retry "
                f"({attempt + 1}/2) ...")
            time.sleep(wait)
    raise RuntimeError(
        "OpenStreetMap (Overpass) is rate-limiting or unavailable right now: "
        f"{last_err}. Wait a minute and try again, or pick a smaller area. "
        "Once fetched, an area is cached locally so retries are instant."
    )


# --------------------------------------------------------------------------- #
# Elevation
# --------------------------------------------------------------------------- #
def fetch_elevation_grid(bbox: BBox, samples: int = 24, log=print):
    """Fetch a coarse elevation grid (samples x samples) over the bbox.

    Returns (grid, lat_step_info). grid[r][c] is metres; r=0 is north.
    The caller interpolates this coarse grid to per-block resolution.
    """
    key = f"elev:{bbox.overpass_str()}:{samples}"
    cached = _cached(key)
    if cached is not None:
        log("Using cached elevation data.")
        return cached

    lats, lons = [], []
    for r in range(samples):
        # r=0 -> north
        lat = bbox.north - (bbox.north - bbox.south) * (r / (samples - 1))
        lats.append(lat)
    for c in range(samples):
        lon = bbox.west + (bbox.east - bbox.west) * (c / (samples - 1))
        lons.append(lon)

    locations = [{"latitude": la, "longitude": lo} for la in lats for lo in lons]

    headers = {"User-Agent": USER_AGENT, "Content-Type": "application/json"}
    grid = None
    for url in ELEVATION_ENDPOINTS:
        try:
            log(f"Querying elevation ({url.split('/')[2]}), {len(locations)} points ...")
            r = requests.post(url, json={"locations": locations}, headers=headers, timeout=90)
            if r.status_code == 200:
                results = r.json()["results"]
                flat = [pt["elevation"] for pt in results]
                grid = [flat[i * samples:(i + 1) * samples] for i in range(samples)]
                break
        except Exception as e:  # noqa: BLE001
            log(f"  elevation endpoint failed: {e}")
            time.sleep(1)

    if grid is None:
        log("Elevation unavailable — using flat terrain.")
        grid = [[0.0] * samples for _ in range(samples)]

    # Normalise so the minimum elevation sits near a sensible build floor.
    flat = [v for row in grid for v in row]
    mn = min(flat)
    grid = [[v - mn for v in row] for row in grid]
    _store(key, grid)
    return grid
