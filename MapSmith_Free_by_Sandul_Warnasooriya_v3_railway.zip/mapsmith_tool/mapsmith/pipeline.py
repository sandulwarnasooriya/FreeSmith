"""End-to-end generation pipeline: bbox + options -> playable world zip.

Author: Sandul Warnasooriya
Built with: Arena.ai (https://arena.ai)
"""

from __future__ import annotations

import os
import re

from . import datasources as ds
from .blocks import get_theme
from .geo import BBox, Projection
from .preview import render_preview, render_iso_preview
from .terrain import build_heightmap, Rasterizer
from .worldbuilder import BASE_Y, WorldBuilder, write_world, zip_world

OUTPUT_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "output")
PREVIEW_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)),
                           "static", "previews")
os.makedirs(OUTPUT_DIR, exist_ok=True)
os.makedirs(PREVIEW_DIR, exist_ok=True)

# Maximum world side length in blocks. Larger areas are auto-scaled down to fit.
# Configurable via the MAPSMITH_MAX_BLOCKS env var so low-RAM hosts (e.g. a
# 512 MiB game-panel container) can cap generation to stay within memory.
#   ~128  -> ~214 MB peak (safe on 512 MiB hosts)
#   ~256  -> ~700 MB peak
#   1024  -> ~1 GB peak (needs a 1 GB+ instance)
MAX_BLOCKS = int(os.environ.get("MAPSMITH_MAX_BLOCKS", "1024"))


def _slug(name: str) -> str:
    s = re.sub(r"[^a-zA-Z0-9_-]+", "_", name).strip("_")
    return s or "mapsmith_world"


def _auto_theme(lat: float) -> str:
    """Rough climate guess from latitude (used when theme='auto')."""
    a = abs(lat)
    if a >= 60:
        return "snowy"
    if a >= 45:
        return "forest"
    if 23 <= a < 35:
        return "desert"      # subtropical dry belt
    if a < 10:
        return "jungle"
    return "plains"


def generate(bbox_coords, spawn_latlon=None, world_name="MapSmith World",
             edition="java", blocks_per_meter=1.0, vscale=1.0,
             elev_samples=24, theme="auto", add_mobs=True,
             add_structures=True, preview_only=False, log=print):
    """Run the full pipeline.

    If preview_only=True, fetch data + rasterise + render preview, but skip the
    (slow) block build and zipping. Returns a dict with a preview image path.
    """
    bbox = BBox.from_list(bbox_coords)
    proj = Projection(bbox, blocks_per_meter)
    width, depth = proj.size_blocks()

    if width > MAX_BLOCKS or depth > MAX_BLOCKS:
        scale = MAX_BLOCKS / max(width, depth)
        blocks_per_meter *= scale
        proj = Projection(bbox, blocks_per_meter)
        width, depth = proj.size_blocks()
        log(f"Area large; scaled to {blocks_per_meter:.3f} blocks/m "
            f"-> {width}x{depth} blocks.")

    width = max(16, width)
    depth = max(16, depth)
    log(f"Target world size: {width} x {depth} blocks "
        f"(~{bbox.width_m():.0f}m x {bbox.height_m():.0f}m).")

    # theme
    if theme in (None, "auto"):
        theme_key = _auto_theme(bbox.center[0])
        log(f"Auto-selected theme: '{theme_key}' (from latitude).")
    else:
        theme_key = theme
    theme_obj = get_theme(theme_key)

    # 1. data
    osm = ds.fetch_osm(bbox, log=log)
    elev = ds.fetch_elevation_grid(bbox, samples=elev_samples, log=log)

    # 2. terrain + raster
    heights = build_heightmap(elev, width, depth, vscale=vscale)
    rast = Rasterizer(bbox, width, depth, blocks_per_meter)
    surface, bld_height = rast.rasterize(osm, log=log)

    # 3. spawn point
    if spawn_latlon:
        sx, sz = proj.to_blocks(spawn_latlon[0], spawn_latlon[1])
    else:
        sx, sz = width / 2, depth / 2
    sx, sz = int(sx), int(sz)
    sx = max(0, min(width - 1, sx))
    sz = max(0, min(depth - 1, sz))
    spawn_y = int(BASE_Y + int(heights[sz, sx]) + 2)

    slug = _slug(world_name)

    # 4. preview images (always): 2D top-down + 3D isometric
    log("Rendering 2D preview ...")
    preview_path = os.path.join(PREVIEW_DIR, f"{slug}.png")
    _, pw, ph = render_preview(surface, heights, theme_key, (sx, sz), preview_path)
    preview_url = f"/static/previews/{slug}.png"

    log("Rendering 3D isometric preview ...")
    iso_path = os.path.join(PREVIEW_DIR, f"{slug}_iso.png")
    iso_url = None
    iso_size = None
    try:
        _, iw, ih = render_iso_preview(
            surface, heights, bld_height, theme_key, (sx, sz), iso_path)
        iso_url = f"/static/previews/{slug}_iso.png"
        iso_size = [iw, ih]
    except Exception as e:  # noqa: BLE001
        log(f"3D preview skipped ({e}).")

    result = {
        "width": width, "depth": depth,
        "spawn": {"x": sx, "y": spawn_y, "z": sz},
        "edition": edition, "theme": theme_key,
        "preview_url": preview_url,
        "preview_size": [pw, ph],
        "iso_url": iso_url,
        "iso_size": iso_size,
    }

    if preview_only:
        log("Preview ready.")
        return result

    # 5. build blocks
    # Always produce both Java and Bedrock outputs so the web UI can offer
    # both download buttons regardless of the selected edition.
    want_bedrock = True
    wb = WorldBuilder(surface, heights, bld_height, (sx, sz), theme_obj,
                      add_mobs=add_mobs, add_structures=add_structures,
                      capture_voxels=want_bedrock, log=log)
    regions = wb.build()

    # 6. write world
    world_dir = os.path.join(OUTPUT_DIR, slug)
    write_world(regions, world_dir, world_name, (sx, sz), spawn_y,
                edition=edition, log=log)

    zip_path = os.path.join(OUTPUT_DIR, f"{slug}_java.zip")
    zip_world(world_dir, zip_path, log=log)

    result.update({
        "world_dir": world_dir,
        "zip_path": zip_path,
        "zip_name": os.path.basename(zip_path),
        "regions": len(regions),
        "structures": wb.structures_count,
        "entities": wb.entities_count,
    })

    if want_bedrock:
        # Built-in Bedrock exporter (beta). Falls back to converter note if it
        # can't run (e.g. LevelDB unavailable on this machine).
        try:
            from .bedrock import export_bedrock, HAVE_PLYVEL
            if HAVE_PLYVEL:
                log("Exporting Bedrock (.mcworld) ...")
                br_dir = os.path.join(OUTPUT_DIR, slug + "_bedrock")
                mcworld = export_bedrock(
                    wb.voxels, br_dir, world_name,
                    (sx, spawn_y, sz), log=log)
                result["mcworld_path"] = mcworld
                result["mcworld_name"] = os.path.basename(mcworld)
                result["bedrock_note"] = (
                    "Bedrock .mcworld generated (beta). Open it in Minecraft "
                    "Bedrock to import. If your game build rejects it, use the "
                    "free Chunker (chunker.app) or Amulet (amuletmc.com) "
                    "converter on the Java ZIP instead."
                )
            else:
                raise RuntimeError("plyvel unavailable")
        except Exception as e:  # noqa: BLE001
            log(f"Bedrock direct export unavailable ({e}); use converter.")
            result["bedrock_note"] = (
                "Bedrock output: import the Java world ZIP into a free "
                "converter such as Amulet Editor (amuletmc.com) or Chunker "
                "(chunker.app) and export as Bedrock (.mcworld). Both are free."
            )
    return result
