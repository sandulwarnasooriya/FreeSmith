"""Assemble a Minecraft Java world from terrain + rasterised features.

Adds, on top of the base terrain/feature rendering:
  * biome-accurate palettes + per-chunk Biomes array (themes)
  * structures (street lamps, wells, market stalls, scarecrows, benches)
  * entities (animals, villagers) written into chunk NBT

Author: Sandul Warnasooriya
Built with: Arena.ai (https://arena.ai)
"""

from __future__ import annotations

import os
import random
import shutil
import time
import zipfile

import numpy as np
from anvil import EmptyRegion
from nbt import nbt

from . import blocks as B
from .mcchunk import BiomeChunk, make_entity
from .terrain import (
    BUILDING, FARM, FOREST, GRASS, LAND, RAIL, ROAD, SAND, WATER, PATH,
)

# The anvil-new writer emits the 1.16.5 "Level" chunk format (Y in 0..255).
BASE_Y = 62
MIN_Y = 0
MAX_Y = 255
SOLID_DEPTH = 4          # top sub-soil layer thickness (dirt/sand/etc.)
# How deep the solid stone base goes beneath each surface point. This must be
# larger than the steepest local height change so neighbouring columns stay
# connected (no floating shell / holes), while staying bounded for memory.
TERRAIN_DEPTH = 40


class WorldBuilder:
    def __init__(self, surface, heights, bld_height, spawn_xz, theme,
                 add_mobs=True, add_structures=True, capture_voxels=False,
                 log=print):
        self.surface = surface
        self.heights = heights
        self.bld_height = bld_height
        self.depth, self.width = surface.shape
        self.spawn_xz = spawn_xz
        self.theme = theme
        self.add_mobs = add_mobs
        self.add_structures = add_structures
        self.log = log
        self.regions = {}
        self.rng = random.Random(42)
        self.entities_count = 0
        self.structures_count = 0
        # Optional voxel capture for the Bedrock exporter:
        # voxels[(x, y, z)] = "minecraft:block_name"
        self.capture_voxels = capture_voxels
        self.voxels = {} if capture_voxels else None

    # -- region/chunk plumbing -------------------------------------------- #
    def _region(self, cx, cz):
        rx, rz = cx >> 5, cz >> 5
        key = (rx, rz)
        if key not in self.regions:
            self.regions[key] = EmptyRegion(rx, rz)
        return self.regions[key]

    def _chunk(self, x, z):
        cx, cz = x >> 4, z >> 4
        region = self._region(cx, cz)
        ch = region.get_chunk(cx, cz)
        if ch is None:
            ch = BiomeChunk(cx, cz)
            region.add_chunk(ch)
        return ch

    def _set(self, x, y, z, block):
        if y < MIN_Y or y > MAX_Y or x < 0 or z < 0 or x >= self.width or z >= self.depth:
            return
        ch = self._chunk(x, z)
        ch.set_block(block, x % 16, y, z % 16)
        if self.voxels is not None:
            name = block.name()
            if name != "minecraft:air":
                self.voxels[(x, y, z)] = name
            else:
                self.voxels.pop((x, y, z), None)

    def _set_biome(self, x, z, biome_id):
        ch = self._chunk(x, z)
        ch.set_biome_cell((x % 16) // 4, (z % 16) // 4, biome_id)

    def _add_entity(self, eid, x, y, z, extra=None):
        ch = self._chunk(int(x), int(z))
        ch.add_entity(make_entity(eid, x, y, z, extra))
        self.entities_count += 1

    # -- main build -------------------------------------------------------- #
    def build(self):
        from .blocks import cell_biome
        w, d = self.width, self.depth
        th = self.theme
        self.log(f"Building {w}x{d} blocks, theme '{th.key}' ...")
        heights, surf = self.heights, self.surface

        rng_np = np.random.default_rng(1234)
        veg_noise = rng_np.random((d, w))

        # Building footprint analysis: a BUILDING cell is a WALL if any
        # orthogonal neighbour is not a building (i.e. it's on the perimeter);
        # otherwise it's interior floor space.
        bmask = (surf == BUILDING)
        wall_mask = np.zeros_like(bmask)
        if bmask.any():
            nb = np.zeros_like(bmask)
            nb[:-1, :] |= ~bmask[1:, :]
            nb[1:, :] |= ~bmask[:-1, :]
            nb[:, :-1] |= ~bmask[:, 1:]
            nb[:, 1:] |= ~bmask[:, :-1]
            nb[0, :] = nb[-1, :] = nb[:, 0] = nb[:, -1] = True
            wall_mask = bmask & nb
        self._wall_mask = wall_mask

        road_cells = []   # for street lamps + entities
        farm_cells = []
        open_cells = []
        water_cells = []
        interior_cells = []   # building interiors, for furniture
        self._road_set = set()  # for connecting paths to doors

        for z in range(d):
            if z % 32 == 0:
                self.log(f"  column row {z}/{d}")
            for x in range(w):
                code = surf[z, x]
                top_off = int(heights[z, x])
                top_y = BASE_Y + top_off

                # Fill a solid base beneath the surface so the world has real
                # depth (not a thin floating shell that looks like "just the top
                # view"). We fill TERRAIN_DEPTH blocks down from the surface,
                # plus a bedrock floor — deep enough to keep neighbouring
                # columns connected, bounded enough to stay memory-friendly.
                self._set(x, MIN_Y, z, B.BEDROCK)
                fill_from = max(MIN_Y + 1, top_y - TERRAIN_DEPTH)
                soil_from = top_y - SOLID_DEPTH
                for y in range(fill_from, top_y):
                    self._set(x, y, z, th.sub if y >= soil_from else B.STONE)

                # biome per cell
                if (x % 4 == 0) and (z % 4 == 0):
                    self._set_biome(x, z, cell_biome(th, code))

                if code == WATER:
                    # The column is already solid up to top_y. Carve a shallow
                    # basin (a couple of blocks) and fill it with water up to
                    # the local surface level so lakes/rivers look filled.
                    bed = max(MIN_Y + 1, top_y - 2)
                    self._set(x, bed, z, th.sub)
                    for y in range(bed + 1, top_y + 1):
                        self._set(x, y, z, B.WATER_BLOCK)
                    if th.snow:
                        self._set(x, top_y, z, B.ICE)
                    water_cells.append((x, z, top_y))
                    continue

                # surface block (themed)
                self._set(x, top_y, z, self._surface_block(code))

                if th.snow and code in (LAND, GRASS, FOREST, FARM):
                    self._set(x, top_y + 1, z, B.SNOW_LAYER)

                # features above surface
                if code == BUILDING:
                    is_wall = bool(self._wall_mask[z, x])
                    self._build_house(x, z, top_y, int(self.bld_height[z, x]),
                                      is_wall)
                    if not is_wall:
                        interior_cells.append((x, z, top_y,
                                               int(self.bld_height[z, x])))
                elif code == FOREST and veg_noise[z, x] < 0.07:
                    self._tree(x, top_y + 1, z)
                elif code in (LAND, GRASS) and veg_noise[z, x] < 0.012:
                    self._tree(x, top_y + 1, z)
                elif code == FARM:
                    self._set(x, top_y, z, B.FARMLAND)
                    if veg_noise[z, x] < 0.3:
                        farm_cells.append((x, z, top_y))

                if code == ROAD:
                    road_cells.append((x, z, top_y))
                    self._road_set.add((x, z))
                elif code in (LAND, GRASS):
                    open_cells.append((x, z, top_y))

        if self.add_structures:
            self._place_structures(road_cells, farm_cells, open_cells, water_cells)
            self._furnish_interiors(interior_cells)
            self._connect_village_paths(road_cells)
        if self.add_mobs:
            self._place_mobs(road_cells, farm_cells, open_cells, water_cells)

        self.log(f"Placed {self.structures_count} structures, "
                 f"{self.entities_count} entities.")
        return self.regions

    def _surface_block(self, code):
        th = self.theme
        if code == ROAD:
            return B.ASPHALT
        if code == PATH:
            return B.GRASS_PATH
        if code == RAIL:
            return B.RAIL_BED
        if code == SAND:
            return th.sand
        if code == FARM:
            return B.FARMLAND
        return th.ground

    # -- vegetation -------------------------------------------------------- #
    def _tree(self, x, base_y, z):
        th = self.theme
        if th.special.get("cactus"):
            for i in range(self.rng.choice([2, 3])):
                self._set(x, base_y + i, z, B.CACTUS)
            return
        h = self.rng.choice([4, 5, 6])
        for i in range(h):
            self._set(x, base_y + i, z, th.log)
        top = base_y + h
        for dz in range(-2, 3):
            for dx in range(-2, 3):
                if abs(dx) + abs(dz) <= 3:
                    self._set(x + dx, top - 1, z + dz, th.leaves)
        for dz in range(-1, 2):
            for dx in range(-1, 2):
                self._set(x + dx, top, z + dz, th.leaves)
        self._set(x, top + 1, z, th.leaves)

    # -- buildings --------------------------------------------------------- #
    def _build_house(self, x, z, ground_y, height, is_wall):
        th = self.theme
        height = max(4, min(height, 40))
        if is_wall:
            # solid exterior wall with windows
            self._set(x, ground_y, z, th.wall2)
            wall = th.wall if (x + z) % 7 else th.wall2
            for h in range(1, height):
                y = ground_y + h
                if 2 <= h <= height - 2 and h % 2 == 0:
                    self._set(x, y, z, B.WINDOW_PANE)
                else:
                    self._set(x, y, z, wall)
            self._set(x, ground_y + height, z, th.roof)
        else:
            # interior: floor + hollow air + ceiling (so you can walk inside)
            self._set(x, ground_y, z, B.SPRUCE_PLANK_FLOOR)
            for h in range(1, height):
                self._set(x, ground_y + h, z, B.AIR)
            self._set(x, ground_y + height, z, th.roof)

    # -- structures -------------------------------------------------------- #
    def _place_structures(self, roads, farms, opens, waters):
        # street lamps every ~10 blocks along roads
        self.rng.shuffle(roads)
        step = max(1, len(roads) // 60) if roads else 1
        for i in range(0, len(roads), max(8, step)):
            x, z, gy = roads[i]
            # place lamp beside the road on an open cell if possible
            self._street_lamp(x, z, gy)

        # a well + market stalls in open areas near roads
        if opens:
            self.rng.shuffle(opens)
            for x, z, gy in opens[: max(1, len(opens) // 800)]:
                self._well(x, z, gy)
            for x, z, gy in opens[len(opens)//2: len(opens)//2 + max(1, len(opens)//900)]:
                self._market_stall(x, z, gy)
            # benches
            for x, z, gy in opens[: max(2, len(opens) // 500)]:
                self._bench(x, z, gy)

        # scarecrows in farmland
        self.rng.shuffle(farms)
        for x, z, gy in farms[: max(1, len(farms) // 200)]:
            self._scarecrow(x, z, gy)

    def _street_lamp(self, x, z, gy):
        for i in range(1, 4):
            self._set(x, gy + i, z, B.OAK_FENCE)
        self._set(x, gy + 4, z, B.LANTERN)
        self.structures_count += 1

    def _well(self, x, z, gy):
        for dx in (-1, 0, 1):
            for dz in (-1, 0, 1):
                if abs(dx) == 1 or abs(dz) == 1:
                    self._set(x + dx, gy, z + dz, B.COBBLE)
                    self._set(x + dx, gy + 1, z + dz, B.COBBLE_WALL)
        self._set(x, gy, z, B.WATER_SRC)
        # roof posts
        for dx, dz in ((-1, -1), (1, 1)):
            for i in range(2, 4):
                self._set(x + dx, gy + i, z + dz, B.OAK_FENCE)
        self._set(x, gy + 4, z, B.OAK_PLANKS)
        self.structures_count += 1

    def _market_stall(self, x, z, gy):
        for dx in (-1, 0, 1):
            self._set(x + dx, gy + 1, z, B.OAK_PLANKS)  # counter
        for dx in (-1, 1):
            for i in range(1, 3):
                self._set(x + dx, gy + i, z - 1, B.OAK_FENCE)
        for dx in (-1, 0, 1):
            self._set(x + dx, gy + 3, z - 1, B.HAY)  # canopy
        self.structures_count += 1

    def _bench(self, x, z, gy):
        self._set(x, gy + 1, z, B.OAK_STAIRS)
        self.structures_count += 1

    def _scarecrow(self, x, z, gy):
        self._set(x, gy + 1, z, B.OAK_FENCE)
        self._set(x, gy + 2, z, B.HAY)
        self._set(x, gy + 3, z, B.PUMPKIN)
        self.structures_count += 1

    # -- interiors --------------------------------------------------------- #
    def _furnish_interiors(self, interior_cells):
        """Place furniture in building interiors and cut a door + light.

        We group interior cells per building (flood-fill on the interior set)
        and place a small furniture set in each room, plus a doorway in the
        nearest wall and a ceiling light.
        """
        if not interior_cells:
            return
        cellmap = {(x, z): (gy, h) for (x, z, gy, h) in interior_cells}
        remaining = set(cellmap.keys())
        rooms = 0
        furnished = 0
        while remaining:
            start = remaining.pop()
            # BFS flood fill this room
            room = [start]
            stack = [start]
            while stack:
                cx, cz = stack.pop()
                for nx, nz in ((cx + 1, cz), (cx - 1, cz), (cx, cz + 1), (cx, cz - 1)):
                    if (nx, nz) in remaining:
                        remaining.discard((nx, nz))
                        room.append((nx, nz))
                        stack.append((nx, nz))
            rooms += 1
            if len(room) < 1:
                continue
            self._furnish_room(room, cellmap)
            furnished += 1
        self.log(f"Furnished {furnished} building interior(s).")

    def _furnish_room(self, room, cellmap):
        # centre + a couple of corners
        xs = [c[0] for c in room]
        zs = [c[1] for c in room]
        gy = cellmap[room[0]][0]
        height = cellmap[room[0]][1]
        cx = sum(xs) // len(xs)
        cz = sum(zs) // len(zs)

        # ceiling light
        ceil = gy + max(3, min(height, 8)) - 1
        if (cx, cz) in cellmap:
            self._set(cx, ceil, cz, B.GLOWSTONE)

        # rug
        if (cx, cz) in cellmap:
            self._set(cx, gy + 1, cz, B.WOOL_RUG)

        # pick furniture spots from room corners (deterministic order)
        room_sorted = sorted(room)
        picks = []
        if len(room_sorted) >= 1:
            picks.append(room_sorted[0])
        if len(room_sorted) >= 2:
            picks.append(room_sorted[-1])
        if len(room_sorted) >= 3:
            picks.append(room_sorted[len(room_sorted) // 2])

        furniture = [B.CRAFTING_TABLE, B.FURNACE, B.CHEST, B.BOOKSHELF,
                     B.FLOWER_POT]
        for i, (fx, fz) in enumerate(picks):
            if (fx, fz) == (cx, cz):
                continue
            self._set(fx, gy + 1, fz, furniture[i % len(furniture)])
            self.structures_count += 1

        # bed (needs two adjacent cells)
        for (bx, bz) in room_sorted:
            if (bx, bz + 1) in cellmap and (bx, bz) != (cx, cz):
                self._set(bx, gy + 1, bz, B.WHITE_BED_HEAD)
                self._set(bx, gy + 1, bz + 1, B.WHITE_BED_FOOT)
                self.structures_count += 1
                break

        # door: find an interior cell on the room edge whose neighbour is a wall
        # cell, and carve a doorway there.
        for (dx, dz) in room_sorted:
            for (wx, wz) in ((dx + 1, dz), (dx - 1, dz), (dx, dz + 1), (dx, dz - 1)):
                if (wx, wz) not in cellmap and self._wall_at(wx, wz):
                    self._set(wx, gy + 1, wz, B.OAK_DOOR_LOWER)
                    self._set(wx, gy + 2, wz, B.OAK_DOOR_UPPER)
                    self.structures_count += 1
                    return

    def _wall_at(self, x, z):
        if 0 <= x < self.width and 0 <= z < self.depth:
            return bool(self._wall_mask[z, x])
        return False

    # -- village paths ----------------------------------------------------- #
    def _connect_village_paths(self, road_cells):
        """Lay short grass-path spurs from buildings toward the nearest road,
        so doorways connect to the street network."""
        if not road_cells or not self._road_set:
            return
        # sample door-ish edge cells: any wall cell adjacent to open ground
        spurs = 0
        roads = list(self._road_set)
        # For each building wall cell, draw a short path toward the closest
        # road within a small radius so doorways connect to the street network.
        wm = self._wall_mask
        ys = self.heights
        step = max(1, int(np.count_nonzero(wm) / 400)) if wm.any() else 1
        coords = np.argwhere(wm)
        for idx in range(0, len(coords), max(1, step)):
            z, x = coords[idx]
            # nearest road within radius 14
            best = None
            bestd = 1e9
            for (rx, rz) in roads:
                dd = (rx - x) ** 2 + (rz - z) ** 2
                if dd < bestd:
                    bestd = dd
                    best = (rx, rz)
                    if dd <= 4:
                        break
            if best is None or bestd > 14 ** 2:
                continue
            # draw straight-ish path from (x,z) to best on open/land cells
            rx, rz = best
            steps = int(max(abs(rx - x), abs(rz - z)))
            for s in range(steps + 1):
                t = s / max(1, steps)
                px = int(round(x + (rx - x) * t))
                pz = int(round(z + (rz - z) * t))
                if not (0 <= px < self.width and 0 <= pz < self.depth):
                    continue
                code = self.surface[pz, px]
                if code in (LAND, GRASS):
                    gy = BASE_Y + int(ys[pz, px])
                    self._set(px, gy, pz, B.GRASS_PATH)
            spurs += 1
        self.log(f"Connected {spurs} building->road path spur(s).")

    # -- mobs -------------------------------------------------------------- #
    def _place_mobs(self, roads, farms, opens, waters):
        th = self.theme
        # villagers near roads
        self.rng.shuffle(roads)
        n_vill = min(20, max(2, len(roads) // 120))
        for i in range(n_vill):
            if not roads:
                break
            x, z, gy = roads[self.rng.randrange(len(roads))]
            prof = self.rng.choice(["farmer", "librarian", "cleric",
                                    "armorer", "butcher", "none"])
            # villager data: VillagerData compound
            vd = nbt.TAG_Compound()
            vd.name = "VillagerData"
            vd.tags.append(nbt.TAG_String(name="type", value="minecraft:plains"))
            vd.tags.append(nbt.TAG_String(name="profession", value=f"minecraft:{prof}"))
            vd.tags.append(nbt.TAG_Int(name="level", value=self.rng.randint(1, 3)))
            self._add_entity("minecraft:villager", x, gy + 1, z, extra=[vd])

        # farm animals on grass/farm
        animals_land = ["minecraft:cow", "minecraft:sheep", "minecraft:pig",
                        "minecraft:chicken", "minecraft:horse"]
        if th.key == "desert":
            animals_land = ["minecraft:camel"] if False else ["minecraft:rabbit"]
        if th.key in ("snowy",):
            animals_land = ["minecraft:polar_bear", "minecraft:rabbit", "minecraft:wolf"]
        if th.key == "savanna":
            animals_land = ["minecraft:horse", "minecraft:cow", "minecraft:llama"]
        if th.key == "jungle":
            animals_land = ["minecraft:parrot", "minecraft:ocelot", "minecraft:chicken"]

        spots = farms + opens
        self.rng.shuffle(spots)
        n_anim = min(60, max(4, len(spots) // 200))
        for i in range(n_anim):
            if not spots:
                break
            x, z, gy = spots[self.rng.randrange(len(spots))]
            self._add_entity(self.rng.choice(animals_land), x, gy + 1, z)

        # fish/squid in water
        self.rng.shuffle(waters)
        for i in range(min(20, len(waters) // 50)):
            x, z, ty = waters[self.rng.randrange(len(waters))]
            self._add_entity(self.rng.choice(["minecraft:squid", "minecraft:cod",
                                              "minecraft:salmon"]),
                             x, BASE_Y - 1, z)


# --------------------------------------------------------------------------- #
# World folder + level.dat + datapack
# --------------------------------------------------------------------------- #
def write_world(regions, out_dir, world_name, spawn_xz, spawn_y, edition="java",
                log=print):
    if os.path.exists(out_dir):
        shutil.rmtree(out_dir)
    region_dir = os.path.join(out_dir, "region")
    os.makedirs(region_dir, exist_ok=True)
    os.makedirs(os.path.join(out_dir, "datapacks"), exist_ok=True)

    for (rx, rz), region in regions.items():
        path = os.path.join(region_dir, f"r.{rx}.{rz}.mca")
        region.save(path)
        log(f"  wrote region r.{rx}.{rz}.mca")

    _write_level_dat(out_dir, world_name, spawn_xz, spawn_y)
    log("Wrote level.dat")


def _write_level_dat(out_dir, world_name, spawn_xz, spawn_y):
    sx, sz = spawn_xz
    root = nbt.NBTFile()
    data = nbt.TAG_Compound()
    data.name = "Data"

    data.tags.append(nbt.TAG_Int(name="DataVersion", value=2586))
    data.tags.append(nbt.TAG_Int(name="version", value=19133))
    ver = nbt.TAG_Compound()
    ver.name = "Version"
    ver.tags.extend([
        nbt.TAG_Int(name="Id", value=2586),
        nbt.TAG_String(name="Name", value="1.16.5"),
        nbt.TAG_Byte(name="Snapshot", value=0),
    ])
    data.tags.append(ver)

    data.tags.append(nbt.TAG_Byte(name="initialized", value=1))
    data.tags.append(nbt.TAG_String(name="LevelName", value=world_name))
    # Authorship — generated by MapSmith Free (Sandul Warnasooriya)
    data.tags.append(nbt.TAG_String(
        name="generatorName", value="MapSmith Free by Sandul Warnasooriya"))
    data.tags.append(nbt.TAG_String(name="Author", value="Sandul Warnasooriya"))
    data.tags.append(nbt.TAG_Long(name="LastPlayed", value=int(time.time() * 1000)))
    data.tags.append(nbt.TAG_Int(name="GameType", value=1))
    data.tags.append(nbt.TAG_Byte(name="allowCommands", value=1))
    data.tags.append(nbt.TAG_Byte(name="hardcore", value=0))
    data.tags.append(nbt.TAG_Int(name="Difficulty", value=1))
    data.tags.append(nbt.TAG_Byte(name="DifficultyLocked", value=0))
    data.tags.append(nbt.TAG_Long(name="Time", value=0))
    data.tags.append(nbt.TAG_Long(name="DayTime", value=6000))
    data.tags.append(nbt.TAG_Byte(name="raining", value=0))
    data.tags.append(nbt.TAG_Byte(name="thundering", value=0))
    data.tags.append(nbt.TAG_Int(name="SpawnX", value=int(sx)))
    data.tags.append(nbt.TAG_Int(name="SpawnY", value=int(spawn_y)))
    data.tags.append(nbt.TAG_Int(name="SpawnZ", value=int(sz)))

    rules = nbt.TAG_Compound()
    rules.name = "GameRules"
    for k, v in {"doDaylightCycle": "true", "doWeatherCycle": "false",
                 "doMobSpawning": "true", "keepInventory": "true"}.items():
        rules.tags.append(nbt.TAG_String(name=k, value=v))
    data.tags.append(rules)

    gen = nbt.TAG_Compound()
    gen.name = "WorldGenSettings"
    gen.tags.append(nbt.TAG_Long(name="seed", value=12345))
    gen.tags.append(nbt.TAG_Byte(name="generate_features", value=0))
    dims = nbt.TAG_Compound()
    dims.name = "dimensions"
    overworld = nbt.TAG_Compound()
    overworld.name = "minecraft:overworld"
    overworld.tags.append(nbt.TAG_String(name="type", value="minecraft:overworld"))
    gen_inner = nbt.TAG_Compound()
    gen_inner.name = "generator"
    gen_inner.tags.append(nbt.TAG_String(name="type", value="minecraft:flat"))
    settings = nbt.TAG_Compound()
    settings.name = "settings"
    settings.tags.append(nbt.TAG_String(name="biome", value="minecraft:plains"))
    settings.tags.append(nbt.TAG_List(name="layers", type=nbt.TAG_Compound))
    settings.tags.append(nbt.TAG_Byte(name="features", value=0))
    settings.tags.append(nbt.TAG_Byte(name="lakes", value=0))
    gen_inner.tags.append(settings)
    overworld.tags.append(gen_inner)
    dims.tags.append(overworld)
    gen.tags.append(dims)
    data.tags.append(gen)

    root.tags.append(data)
    root.name = ""
    root.write_file(os.path.join(out_dir, "level.dat"))


def zip_world(world_dir, zip_path, log=print):
    name = os.path.basename(world_dir)
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for root_dir, _dirs, files in os.walk(world_dir):
            for fn in files:
                full = os.path.join(root_dir, fn)
                arc = os.path.join(name, os.path.relpath(full, world_dir))
                zf.write(full, arc)
    log(f"Zipped world -> {os.path.basename(zip_path)}")
    return zip_path
