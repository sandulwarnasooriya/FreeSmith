"""Build per-block heightmaps and rasterise OSM features onto a block grid.

Author: Sandul Warnasooriya
Built with: Arena.ai (https://arena.ai)
"""

from __future__ import annotations

import math

import numpy as np

from .geo import BBox, Projection


def build_heightmap(elev_grid, width: int, depth: int, vscale: float = 1.0):
    """Bilinearly interpolate a coarse elevation grid to per-block resolution.

    Returns an int numpy array of shape (depth, width) of surface Y offsets
    (relative to the build base), with `depth` rows (z) and `width` cols (x).
    """
    g = np.asarray(elev_grid, dtype=np.float64)
    rows, cols = g.shape

    # target sample positions in source-grid coordinates
    zs = np.linspace(0, rows - 1, depth)
    xs = np.linspace(0, cols - 1, width)

    z0 = np.floor(zs).astype(int)
    z1 = np.minimum(z0 + 1, rows - 1)
    x0 = np.floor(xs).astype(int)
    x1 = np.minimum(x0 + 1, cols - 1)
    zf = (zs - z0)[:, None]
    xf = (xs - x0)[None, :]

    top = g[z0][:, x0] * (1 - xf) + g[z0][:, x1] * xf
    bot = g[z1][:, x0] * (1 - xf) + g[z1][:, x1] * xf
    interp = top * (1 - zf) + bot * zf

    return np.rint(interp * vscale).astype(np.int32)


# Feature raster codes (what occupies each surface cell)
LAND = 0
WATER = 1
ROAD = 2
PATH = 3
BUILDING = 4
FOREST = 5
FARM = 6
GRASS = 7
SAND = 8
RAIL = 9

# landuse/natural tag -> code
LANDUSE_MAP = {
    "forest": FOREST, "wood": FOREST,
    "farmland": FARM, "farmyard": FARM, "orchard": FARM, "vineyard": FARM,
    "grass": GRASS, "meadow": GRASS, "recreation_ground": GRASS,
    "village_green": GRASS, "park": GRASS, "garden": GRASS, "cemetery": GRASS,
    "sand": SAND, "beach": SAND, "scrub": GRASS, "heath": GRASS,
    "residential": LAND, "commercial": LAND, "industrial": LAND, "retail": LAND,
}

HIGHWAY_WIDTH = {
    "motorway": 8, "trunk": 7, "primary": 6, "secondary": 5,
    "tertiary": 4, "unclassified": 3, "residential": 3, "service": 2,
    "living_street": 3, "pedestrian": 3,
}
PATH_TYPES = {"footway", "path", "track", "cycleway", "bridleway", "steps"}


class Rasterizer:
    """Turns OSM geometry into a 2D grid of feature codes + building heights."""

    def __init__(self, bbox: BBox, width: int, depth: int, blocks_per_meter: float = 1.0):
        self.proj = Projection(bbox, blocks_per_meter)
        self.width = width
        self.depth = depth
        self.surface = np.full((depth, width), LAND, dtype=np.uint8)
        self.bld_height = np.zeros((depth, width), dtype=np.uint8)

    # -- low level drawing ------------------------------------------------- #
    def _pts(self, geometry):
        out = []
        for node in geometry:
            x, z = self.proj.to_blocks(node["lat"], node["lon"])
            out.append((x, z))
        return out

    def _draw_polygon(self, pts, code, height=0):
        if len(pts) < 3:
            return
        xs = [p[0] for p in pts]
        zs = [p[1] for p in pts]
        minz = max(0, int(math.floor(min(zs))))
        maxz = min(self.depth - 1, int(math.ceil(max(zs))))
        n = len(pts)
        for z in range(minz, maxz + 1):
            yc = z + 0.5
            nodes = []
            j = n - 1
            for i in range(n):
                zi, zj = zs[i], zs[j]
                if (zi < yc <= zj) or (zj < yc <= zi):
                    t = (yc - zi) / (zj - zi)
                    nodes.append(xs[i] + t * (xs[j] - xs[i]))
                j = i
            nodes.sort()
            for k in range(0, len(nodes) - 1, 2):
                xa = max(0, int(math.ceil(nodes[k])))
                xb = min(self.width - 1, int(math.floor(nodes[k + 1])))
                for x in range(xa, xb + 1):
                    self.surface[z, x] = code
                    if height:
                        self.bld_height[z, x] = min(255, height)

    def _draw_line(self, pts, code, thickness):
        half = max(0.5, thickness / 2.0)
        for (x0, z0), (x1, z1) in zip(pts, pts[1:]):
            dist = math.hypot(x1 - x0, z1 - z0)
            steps = max(1, int(dist))
            for s in range(steps + 1):
                t = s / steps
                cx = x0 + (x1 - x0) * t
                cz = z0 + (z1 - z0) * t
                r = int(math.ceil(half))
                for dz in range(-r, r + 1):
                    for dx in range(-r, r + 1):
                        if dx * dx + dz * dz <= half * half:
                            x = int(cx + dx)
                            z = int(cz + dz)
                            if 0 <= x < self.width and 0 <= z < self.depth:
                                self.surface[z, x] = code

    # -- public ------------------------------------------------------------ #
    def rasterize(self, osm: dict, log=print):
        elements = osm.get("elements", [])
        # Painter's order: landuse/water first, then roads, then buildings on top
        polys_landuse, waters, roads, paths, rails, buildings = [], [], [], [], [], []

        for el in elements:
            if el.get("type") not in ("way", "relation"):
                continue
            geom = el.get("geometry")
            if not geom:
                continue
            tags = el.get("tags", {})
            if "building" in tags:
                buildings.append((geom, tags))
            elif "highway" in tags:
                hw = tags["highway"]
                if hw in PATH_TYPES:
                    paths.append((geom, hw))
                else:
                    roads.append((geom, hw))
            elif "railway" in tags:
                rails.append(geom)
            elif tags.get("natural") == "water" or "waterway" in tags:
                waters.append((geom, "waterway" in tags))
            elif "landuse" in tags or "natural" in tags or "leisure" in tags:
                key = tags.get("landuse") or tags.get("natural") or tags.get("leisure")
                code = LANDUSE_MAP.get(key, LAND)
                if code != LAND:
                    polys_landuse.append((geom, code))

        log(f"Rasterising: {len(polys_landuse)} landuse, {len(waters)} water, "
            f"{len(roads)} roads, {len(paths)} paths, {len(buildings)} buildings.")

        for geom, code in polys_landuse:
            self._draw_polygon(self._pts(geom), code)

        for geom, is_waterway in waters:
            pts = self._pts(geom)
            if is_waterway:
                self._draw_line(pts, WATER, 3)
            else:
                self._draw_polygon(pts, WATER)

        for geom in rails:
            self._draw_line(self._pts(geom), RAIL, 2)

        for geom, hw in roads:
            self._draw_line(self._pts(geom), ROAD, HIGHWAY_WIDTH.get(hw, 3))

        for geom, hw in paths:
            self._draw_line(self._pts(geom), PATH, 1)

        for geom, tags in buildings:
            h = self._building_height(tags)
            self._draw_polygon(self._pts(geom), BUILDING, height=h)

        return self.surface, self.bld_height

    @staticmethod
    def _building_height(tags) -> int:
        # explicit height
        if "height" in tags:
            try:
                return max(3, int(round(float(str(tags["height"]).split()[0]))))
            except Exception:
                pass
        if "building:levels" in tags:
            try:
                return max(3, int(round(float(tags["building:levels"]))) * 3)
            except Exception:
                pass
        return 5  # default ~1.5 storeys
