"""Geographic helpers: bounding boxes and lat/lon -> block-grid projection.

We use a simple local equirectangular projection. For the small areas this tool
targets (a town / neighbourhood, up to a few km across) the distortion is
negligible and keeps the maths fast and dependency-free.

1 block = 1 metre (configurable via `blocks_per_meter`).

Author: Sandul Warnasooriya
Built with: Arena.ai (https://arena.ai)
"""

from __future__ import annotations

import math
from dataclasses import dataclass

EARTH_RADIUS_M = 6_378_137.0


@dataclass
class BBox:
    """A geographic bounding box (degrees)."""

    south: float
    west: float
    north: float
    east: float

    @classmethod
    def from_list(cls, coords) -> "BBox":
        # Accepts [south, west, north, east]
        s, w, n, e = coords
        return cls(min(s, n), min(w, e), max(s, n), max(w, e))

    @property
    def center(self):
        return ((self.south + self.north) / 2.0, (self.west + self.east) / 2.0)

    def overpass_str(self) -> str:
        # Overpass expects (south,west,north,east)
        return f"{self.south},{self.west},{self.north},{self.east}"

    def width_m(self) -> float:
        _, clon = self.center
        lat0 = math.radians((self.south + self.north) / 2.0)
        return abs(self.east - self.west) * (math.pi / 180.0) * EARTH_RADIUS_M * math.cos(lat0)

    def height_m(self) -> float:
        return abs(self.north - self.south) * (math.pi / 180.0) * EARTH_RADIUS_M


class Projection:
    """Projects lon/lat to local metre/block coordinates.

    Origin (0,0) is the south-west corner of the bbox. X grows east, Z grows
    south (to match Minecraft's coordinate system where +Z is south).
    """

    def __init__(self, bbox: BBox, blocks_per_meter: float = 1.0):
        self.bbox = bbox
        self.bpm = blocks_per_meter
        self.lat0 = math.radians(bbox.center[0])
        self._mx = (math.pi / 180.0) * EARTH_RADIUS_M * math.cos(self.lat0)
        self._mz = (math.pi / 180.0) * EARTH_RADIUS_M

    def to_blocks(self, lat: float, lon: float):
        """Return (x, z) integer block coordinates."""
        x = (lon - self.bbox.west) * self._mx * self.bpm
        # north is smaller z, south is larger z
        z = (self.bbox.north - lat) * self._mz * self.bpm
        return x, z

    def size_blocks(self):
        w = self.bbox.width_m() * self.bpm
        h = self.bbox.height_m() * self.bpm
        return int(math.ceil(w)), int(math.ceil(h))
