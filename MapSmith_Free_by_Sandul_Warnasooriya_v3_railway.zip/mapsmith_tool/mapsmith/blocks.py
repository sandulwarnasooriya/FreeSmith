"""Block palettes + biome themes.

Everything here is restricted to blocks/biomes that exist in Minecraft 1.16.5,
the version the world writer targets (newer clients auto-upgrade the world).

A *theme* picks a climate (its Minecraft biome id, so grass/water/foliage colours
render correctly) and the set of blocks used for ground, trees, buildings, etc.

Author: Sandul Warnasooriya
Built with: Arena.ai (https://arena.ai)
"""

from anvil import Block

from .terrain import (
    LAND, WATER, ROAD, PATH, BUILDING, FOREST, FARM, GRASS, SAND, RAIL,
)

# -- generic blocks --------------------------------------------------------- #
AIR = Block("minecraft", "air")
STONE = Block("minecraft", "stone")
DIRT = Block("minecraft", "dirt")
GRASS_BLOCK = Block("minecraft", "grass_block")
WATER_BLOCK = Block("minecraft", "water")
SAND_BLOCK = Block("minecraft", "sand")
RED_SAND = Block("minecraft", "red_sand")
SANDSTONE = Block("minecraft", "sandstone")
GRAVEL = Block("minecraft", "gravel")
COARSE_DIRT = Block("minecraft", "coarse_dirt")
FARMLAND = Block("minecraft", "farmland")
PODZOL = Block("minecraft", "podzol")
GRASS_PATH = Block("minecraft", "grass_path")
SNOW_BLOCK = Block("minecraft", "snow_block")
SNOW_LAYER = Block("minecraft", "snow")
ICE = Block("minecraft", "ice")
PACKED_ICE = Block("minecraft", "packed_ice")
TERRACOTTA = Block("minecraft", "terracotta")
CLAY = Block("minecraft", "clay")
MOSSY_COBBLE = Block("minecraft", "mossy_cobblestone")
BEDROCK = Block("minecraft", "bedrock")

ASPHALT = Block("minecraft", "gray_concrete")
RAIL_BED = Block("minecraft", "andesite")

# building materials
WHITE_CONCRETE = Block("minecraft", "white_concrete")
LIGHT_GRAY_CONCRETE = Block("minecraft", "light_gray_concrete")
GLASS = Block("minecraft", "glass")
STONE_BRICKS = Block("minecraft", "stone_bricks")
SANDSTONE_SMOOTH = Block("minecraft", "smooth_sandstone")
SPRUCE_PLANKS = Block("minecraft", "spruce_planks")
SPRUCE_LOG = Block("minecraft", "spruce_log")
DARK_OAK_PLANKS = Block("minecraft", "dark_oak_planks")
TERRACOTTA_WHITE = Block("minecraft", "white_terracotta")
TERRACOTTA_ORANGE = Block("minecraft", "orange_terracotta")
BRICKS = Block("minecraft", "bricks")

# tree parts (per theme)
OAK_LOG = Block("minecraft", "oak_log")
OAK_LEAVES = Block("minecraft", "oak_leaves", {"persistent": "true"})
SPRUCE_LEAVES = Block("minecraft", "spruce_leaves", {"persistent": "true"})
JUNGLE_LOG = Block("minecraft", "jungle_log")
JUNGLE_LEAVES = Block("minecraft", "jungle_leaves", {"persistent": "true"})
ACACIA_LOG = Block("minecraft", "acacia_log")
ACACIA_LEAVES = Block("minecraft", "acacia_leaves", {"persistent": "true"})
DARK_OAK_LOG = Block("minecraft", "dark_oak_log")
CACTUS = Block("minecraft", "cactus")
DEAD_BUSH = Block("minecraft", "dead_bush")

# decoration / structures
LANTERN = Block("minecraft", "lantern")
OAK_FENCE = Block("minecraft", "oak_fence")
TORCH = Block("minecraft", "torch")
COBBLE = Block("minecraft", "cobblestone")
COBBLE_WALL = Block("minecraft", "cobblestone_wall")
HAY = Block("minecraft", "hay_block")
OAK_PLANKS = Block("minecraft", "oak_planks")
OAK_STAIRS = Block("minecraft", "oak_stairs")
CAMPFIRE = Block("minecraft", "campfire")
BELL = Block("minecraft", "bell")
WATER_SRC = Block("minecraft", "water")
PUMPKIN = Block("minecraft", "carved_pumpkin", {"facing": "south"})

# -- interior furniture (1.16.5) ------------------------------------------- #
OAK_DOOR_LOWER = Block("minecraft", "oak_door",
                       {"half": "lower", "facing": "north", "hinge": "left",
                        "open": "false", "powered": "false"})
OAK_DOOR_UPPER = Block("minecraft", "oak_door",
                       {"half": "upper", "facing": "north", "hinge": "left",
                        "open": "false", "powered": "false"})
WHITE_BED_FOOT = Block("minecraft", "white_bed",
                       {"part": "foot", "facing": "north", "occupied": "false"})
WHITE_BED_HEAD = Block("minecraft", "white_bed",
                       {"part": "head", "facing": "north", "occupied": "false"})
CRAFTING_TABLE = Block("minecraft", "crafting_table")
FURNACE = Block("minecraft", "furnace", {"facing": "north", "lit": "false"})
CHEST = Block("minecraft", "chest", {"facing": "north", "type": "single"})
BOOKSHELF = Block("minecraft", "bookshelf")
WOOL_RUG = Block("minecraft", "light_blue_carpet")
FLOWER_POT = Block("minecraft", "flower_pot")
WALL_TORCH = Block("minecraft", "wall_torch", {"facing": "north"})
GLOWSTONE = Block("minecraft", "glowstone")
LADDER = Block("minecraft", "ladder", {"facing": "north"})
SPRUCE_PLANK_FLOOR = Block("minecraft", "spruce_planks")
WINDOW_PANE = Block("minecraft", "glass_pane")

# Minecraft 1.16.5 numeric biome ids
BIOME = {
    "plains": 1, "desert": 2, "forest": 4, "swamp": 6, "river": 7,
    "ocean": 0, "snowy_tundra": 12, "beach": 16, "jungle": 21,
    "savanna": 35, "snowy_taiga": 30, "taiga": 5,
}


class Theme:
    """A climate theme: base biome + block choices."""

    def __init__(self, key, biome, ground, sub, sand, log, leaves,
                 wall, wall2, roof, water_top=None, snow=False, special=None):
        self.key = key
        self.biome = biome            # base biome id
        self.ground = ground          # surface grass/ground
        self.sub = sub                # block just under surface
        self.sand = sand
        self.log = log
        self.leaves = leaves
        self.wall = wall
        self.wall2 = wall2
        self.roof = roof
        self.snow = snow              # add snow layer on top
        self.special = special or {}  # e.g. cactus instead of tree


THEMES = {
    "plains": Theme("plains", BIOME["plains"], GRASS_BLOCK, DIRT, SAND_BLOCK,
                    OAK_LOG, OAK_LEAVES, WHITE_CONCRETE, LIGHT_GRAY_CONCRETE,
                    STONE_BRICKS),
    "forest": Theme("forest", BIOME["forest"], GRASS_BLOCK, DIRT, SAND_BLOCK,
                    OAK_LOG, OAK_LEAVES, OAK_PLANKS, SPRUCE_PLANKS, DARK_OAK_PLANKS),
    "desert": Theme("desert", BIOME["desert"], SAND_BLOCK, SANDSTONE, SAND_BLOCK,
                    OAK_LOG, OAK_LEAVES, SANDSTONE_SMOOTH, SANDSTONE, SANDSTONE,
                    special={"cactus": True}),
    "snowy": Theme("snowy", BIOME["snowy_tundra"], SNOW_BLOCK, DIRT, SNOW_BLOCK,
                   SPRUCE_LOG, SPRUCE_LEAVES, SPRUCE_PLANKS, STONE_BRICKS,
                   STONE_BRICKS, snow=True),
    "jungle": Theme("jungle", BIOME["jungle"], GRASS_BLOCK, DIRT, SAND_BLOCK,
                    JUNGLE_LOG, JUNGLE_LEAVES, JUNGLE_LOG, MOSSY_COBBLE,
                    DARK_OAK_PLANKS),
    "savanna": Theme("savanna", BIOME["savanna"], GRASS_BLOCK, DIRT, SAND_BLOCK,
                     ACACIA_LOG, ACACIA_LEAVES, TERRACOTTA_ORANGE, ACACIA_LOG,
                     TERRACOTTA_WHITE),
    "swamp": Theme("swamp", BIOME["swamp"], GRASS_BLOCK, CLAY, SAND_BLOCK,
                   OAK_LOG, OAK_LEAVES, SPRUCE_PLANKS, MOSSY_COBBLE, DARK_OAK_PLANKS),
}


def get_theme(key: str) -> Theme:
    return THEMES.get(key, THEMES["plains"])


# Per-cell biome override based on feature (so water/forest colour correctly).
def cell_biome(theme: Theme, code: int) -> int:
    if code == WATER:
        return BIOME["river"]
    if code == SAND:
        return BIOME["beach"] if not theme.snow else theme.biome
    if code == FOREST and theme.key in ("plains", "forest"):
        return BIOME["forest"]
    return theme.biome
