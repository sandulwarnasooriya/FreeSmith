"""Visitor logging — record real human visitors, filter out bots/scanners.

Writes a human-readable line per genuine visit to ``logs/visitors.log`` and a
machine-readable copy to ``logs/visitors.jsonl``. Obvious bots, crawlers,
uptime pingers and malformed/scanner requests are skipped so the log shows
people, not noise.

Author: Sandul Warnasooriya
Built with: Arena.ai (https://arena.ai)
"""

from __future__ import annotations

import json
import os
import re
import threading
from datetime import datetime, timezone

LOG_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "logs")
os.makedirs(LOG_DIR, exist_ok=True)
TEXT_LOG = os.path.join(LOG_DIR, "visitors.log")
JSON_LOG = os.path.join(LOG_DIR, "visitors.jsonl")

_LOCK = threading.Lock()

# User-agent substrings that indicate a bot / crawler / monitor / scanner.
_BOT_UA = re.compile(
    r"bot|crawl|spider|slurp|bingpreview|facebookexternalhit|embedly|"
    r"curl|wget|python-requests|httpx|aiohttp|go-http-client|java/|okhttp|"
    r"libwww|scrapy|headlesschrome|phantomjs|monitor|uptime|pingdom|"
    r"statuscake|nmap|masscan|zgrab|censys|shodan|nuclei|semrush|ahrefs|"
    r"dataprovider|expanse|paloalto|netcraft|petalbot|gptbot|ccbot|"
    r"dotbot|mj12bot|bytespider|amazonbot|googlebot|yandex|baidu",
    re.IGNORECASE,
)

# Paths that are clearly probes for vulnerabilities / other software.
_PROBE_PATH = re.compile(
    r"(\.php|\.env|\.git|\.aws|wp-|wordpress|phpmyadmin|admin|xmlrpc|"
    r"/cgi-bin|/actuator|/vendor/|/\.well-known/(?!$)|boaform|hnap|"
    r"setup\.cgi|/owa/|/autodiscover|/manager/html|eval-stdin)",
    re.IGNORECASE,
)

# Only these "human" entry points count as a real visit (avoid logging every
# static asset / status poll, which would flood the file).
_COUNT_PATHS = ("/", "/api/generate")


def is_bot(user_agent: str, path: str) -> bool:
    ua = user_agent or ""
    if not ua.strip():
        return True  # real browsers always send a UA; empty == bot/scanner
    if _BOT_UA.search(ua):
        return True
    if _PROBE_PATH.search(path or ""):
        return True
    return False


def _client_ip(request) -> str:
    # Respect a reverse proxy if one is in front (Cloudflare/Render/etc.)
    xff = request.headers.get("X-Forwarded-For", "")
    if xff:
        return xff.split(",")[0].strip()
    return request.remote_addr or "?"


def log_visit(request, action: str = "visit", extra: dict | None = None) -> None:
    """Record a genuine human visit. No-op for bots/probes."""
    ua = request.headers.get("User-Agent", "")
    path = request.path
    if is_bot(ua, path):
        return

    ip = _client_ip(request)
    now = datetime.now(timezone.utc).astimezone()
    ref = request.headers.get("Referer", "")
    lang = request.headers.get("Accept-Language", "").split(",")[0]

    record = {
        "time": now.isoformat(timespec="seconds"),
        "ip": ip,
        "action": action,
        "path": path,
        "user_agent": ua,
        "referer": ref,
        "lang": lang,
    }
    if extra:
        record.update(extra)

    line = (f"{record['time']}  {ip:<15}  {action:<8}  "
            f"{path}  | {lang or '-'} | {ua}")
    if extra:
        line += "  | " + " ".join(f"{k}={v}" for k, v in extra.items())

    with _LOCK:
        try:
            with open(TEXT_LOG, "a", encoding="utf-8") as f:
                f.write(line + "\n")
            with open(JSON_LOG, "a", encoding="utf-8") as f:
                f.write(json.dumps(record, ensure_ascii=False) + "\n")
        except Exception:
            pass


def read_recent(limit: int = 200):
    """Return the most recent visitor records (newest first)."""
    if not os.path.exists(JSON_LOG):
        return []
    out = []
    with _LOCK:
        try:
            with open(JSON_LOG, "r", encoding="utf-8") as f:
                lines = f.readlines()
        except Exception:
            return []
    for ln in lines[-limit:]:
        try:
            out.append(json.loads(ln))
        except Exception:
            continue
    out.reverse()
    return out


def summary():
    """Quick stats: total visits + unique IPs."""
    recs = read_recent(limit=100000)
    ips = {r.get("ip") for r in recs}
    gens = sum(1 for r in recs if r.get("action") == "generate")
    return {"total_visits": len(recs), "unique_ips": len(ips),
            "worlds_generated": gens}
