"""Minimal little-endian NBT writer for Bedrock Edition.

Bedrock stores NBT in little-endian byte order (Java is big-endian, which the
`nbt` package handles). This module implements just enough tag types to write
Bedrock level.dat and block-palette compounds.

Author: Sandul Warnasooriya
Built with: Arena.ai (https://arena.ai)
"""

from __future__ import annotations

import struct

TAG_END = 0
TAG_BYTE = 1
TAG_SHORT = 2
TAG_INT = 3
TAG_LONG = 4
TAG_FLOAT = 5
TAG_DOUBLE = 6
TAG_BYTE_ARRAY = 7
TAG_STRING = 8
TAG_LIST = 9
TAG_COMPOUND = 10
TAG_INT_ARRAY = 11
TAG_LONG_ARRAY = 12


class Tag:
    tid = None

    def payload(self) -> bytes:  # pragma: no cover - interface
        raise NotImplementedError


class Byte(Tag):
    tid = TAG_BYTE

    def __init__(self, v): self.v = int(v)
    def payload(self): return struct.pack("<b", self.v)


class Short(Tag):
    tid = TAG_SHORT

    def __init__(self, v): self.v = int(v)
    def payload(self): return struct.pack("<h", self.v)


class Int(Tag):
    tid = TAG_INT

    def __init__(self, v): self.v = int(v)
    def payload(self): return struct.pack("<i", self.v)


class Long(Tag):
    tid = TAG_LONG

    def __init__(self, v): self.v = int(v)
    def payload(self): return struct.pack("<q", self.v)


class Float(Tag):
    tid = TAG_FLOAT

    def __init__(self, v): self.v = float(v)
    def payload(self): return struct.pack("<f", self.v)


class Double(Tag):
    tid = TAG_DOUBLE

    def __init__(self, v): self.v = float(v)
    def payload(self): return struct.pack("<d", self.v)


class String(Tag):
    tid = TAG_STRING

    def __init__(self, v): self.v = v

    def payload(self):
        data = self.v.encode("utf-8")
        return struct.pack("<H", len(data)) + data


class List(Tag):
    tid = TAG_LIST

    def __init__(self, item_tid, items):
        self.item_tid = item_tid
        self.items = items  # list of Tag

    def payload(self):
        out = struct.pack("<b", self.item_tid) + struct.pack("<i", len(self.items))
        for it in self.items:
            out += it.payload()
        return out


class Compound(Tag):
    tid = TAG_COMPOUND

    def __init__(self, items=None):
        self.items = items or {}  # name -> Tag

    def set(self, name, tag):
        self.items[name] = tag
        return self

    def payload(self):
        out = b""
        for name, tag in self.items.items():
            out += _named(tag.tid, name) + tag.payload()
        out += struct.pack("<b", TAG_END)
        return out


def _named(tid, name):
    nb = name.encode("utf-8")
    return struct.pack("<b", tid) + struct.pack("<H", len(nb)) + nb


def write_named_compound(name: str, comp: Compound) -> bytes:
    """Serialize a root named compound (used for palette entries)."""
    return _named(TAG_COMPOUND, name) + comp.payload()


def write_level_dat(comp: Compound) -> bytes:
    """level.dat = 8-byte header (version, length) + LE NBT compound."""
    body = _named(TAG_COMPOUND, "") + comp.payload()
    header = struct.pack("<i", 9) + struct.pack("<i", len(body))  # storage v9
    return header + body
