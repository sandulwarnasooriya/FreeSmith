"""Bedrock Edition (.mcworld) exporter.

Writes a Bedrock world from a captured voxel map using the LevelDB chunk
format. This produces:

    <world>/
        level.dat            (little-endian NBT, storage version 9)
        levelname.txt
        db/                  (LevelDB key/value store with sub-chunks)

…then zips it as <name>.mcworld (a plain zip of the world folder contents).

NOTE
----
Bedrock's world format is complex and version-sensitive. This exporter targets
the persistent sub-chunk format (version 9) with a per-sub-chunk block palette.
It is provided as a *beta* convenience. If a particular game build refuses it,
use the documented free converter path (Chunker / Amulet) on the Java ZIP,
which is always reliable.

Author: Sandul Warnasooriya
Built with: Arena.ai (https://arena.ai)
"""

from __future__ import annotations

import os
import shutil
import struct
import zipfile

try:
    import plyvel
    HAVE_PLYVEL = True
except Exception:  # noqa: BLE001
    HAVE_PLYVEL = False

from . import lenbt as L

# Bedrock numeric biome (plains) — biome data uses a simpler paletted format.
DEFAULT_BIOME = 1

# Dimension 0 = overworld
OVERWORLD = 0


def _subchunk_key(cx, cz, cy, dimension=OVERWORLD):
    """LevelDB key for a SubChunkPrefix (0x2f) record."""
    if dimension == OVERWORLD:
        return struct.pack("<ii", cx, cz) + bytes([0x2f]) + struct.pack("<b", cy)
    return (struct.pack("<ii", cx, cz) + struct.pack("<i", dimension)
            + bytes([0x2f]) + struct.pack("<b", cy))


def _version_key(cx, cz, dimension=OVERWORLD):
    if dimension == OVERWORLD:
        return struct.pack("<ii", cx, cz) + bytes([0x2c])  # version tag
    return struct.pack("<ii", cx, cz) + struct.pack("<i", dimension) + bytes([0x2c])


def _data2d_key(cx, cz, dimension=OVERWORLD):
    if dimension == OVERWORLD:
        return struct.pack("<ii", cx, cz) + bytes([0x2d])  # Data2D (heightmap+biome)
    return struct.pack("<ii", cx, cz) + struct.pack("<i", dimension) + bytes([0x2d])


def _palette_entry(name: str) -> bytes:
    """A block palette entry: a named-LE-NBT compound {name, states{}, version}."""
    comp = L.Compound()
    comp.set("name", L.String(name))
    comp.set("states", L.Compound())  # default states (best-effort)
    comp.set("version", L.Int(17879555))  # 1.18.x block version
    return L.write_named_compound("", comp)


def _encode_subchunk(block_ids, palette_names):
    """Encode one 16x16x16 sub-chunk (format version 8, 1 storage layer).

    block_ids: list of 4096 palette indices, ordered x*256 + z*16 + y
               (Bedrock packed order: X high, then Z, then Y low).
    palette_names: list of "minecraft:..." strings.
    """
    n_palette = len(palette_names)
    # bits per block: smallest power-friendly value that fits the palette
    import math
    bits = max(1, (n_palette - 1).bit_length())
    for allowed in (1, 2, 3, 4, 5, 6, 8, 16):
        if bits <= allowed:
            bits = allowed
            break
    blocks_per_word = 32 // bits
    n_words = math.ceil(4096 / blocks_per_word)

    out = bytearray()
    out.append(8)            # sub-chunk format version 8
    out.append(1)            # storage layer count

    # storage header: (bits << 1) | (1 = runtime? no -> 0 for persistence)
    out.append((bits << 1) | 0)

    # packed block indices
    words = bytearray()
    pos = 0
    for _w in range(n_words):
        word = 0
        for b in range(blocks_per_word):
            if pos >= 4096:
                break
            word |= (block_ids[pos] & ((1 << bits) - 1)) << (bits * b)
            pos += 1
        words += struct.pack("<I", word)
    out += words

    # palette size (LE int) + palette NBT entries
    out += struct.pack("<i", n_palette)
    for name in palette_names:
        out += _palette_entry(name)
    return bytes(out)


def export_bedrock(voxels, out_dir, world_name, spawn_xyz, min_y=0, max_y=255,
                   log=print):
    """Write a Bedrock world from a voxel dict to out_dir; return mcworld path."""
    if not HAVE_PLYVEL:
        raise RuntimeError(
            "plyvel/LevelDB not available — cannot write Bedrock directly. "
            "Use the Chunker/Amulet converter on the Java ZIP instead.")

    if os.path.exists(out_dir):
        shutil.rmtree(out_dir)
    os.makedirs(out_dir, exist_ok=True)
    db_dir = os.path.join(out_dir, "db")
    os.makedirs(db_dir, exist_ok=True)

    # group voxels into chunk columns -> sub-chunks
    # chunk (cx,cz); sub-chunk cy; local index x*256+z*16+y
    log("Bedrock: indexing voxels into sub-chunks ...")
    sub = {}  # (cx,cz,cy) -> dict(local_index -> name)
    chunks = set()
    for (x, y, z), name in voxels.items():
        cx, cz = x >> 4, z >> 4
        cy = y >> 4
        lx, ly, lz = x & 15, y & 15, z & 15
        idx = (lx << 8) | (lz << 4) | ly
        sub.setdefault((cx, cz, cy), {})[idx] = name
        chunks.add((cx, cz))

    db = plyvel.DB(db_dir, create_if_missing=True)
    try:
        AIR = "minecraft:air"
        written = 0
        for (cx, cz, cy), cells in sub.items():
            # build palette (air always index 0)
            palette = [AIR]
            pindex = {AIR: 0}
            ids = [0] * 4096
            for idx, name in cells.items():
                if name not in pindex:
                    pindex[name] = len(palette)
                    palette.append(name)
                ids[idx] = pindex[name]
            data = _encode_subchunk(ids, palette)
            db.put(_subchunk_key(cx, cz, cy), data)
            written += 1

        # per-chunk version + Data2D (heightmap + biomes)
        for (cx, cz) in chunks:
            db.put(_version_key(cx, cz), bytes([40]))  # chunk version 40 (1.18)
            # Data2D: 256 little-endian shorts heightmap + 256 bytes biome
            d2d = bytearray()
            for _ in range(256):
                d2d += struct.pack("<H", 0)
            d2d += bytes([DEFAULT_BIOME]) * 256
            db.put(_data2d_key(cx, cz), bytes(d2d))
        log(f"Bedrock: wrote {written} sub-chunks across {len(chunks)} chunks.")
    finally:
        db.close()

    _write_bedrock_level_dat(out_dir, world_name, spawn_xyz)
    with open(os.path.join(out_dir, "levelname.txt"), "w") as f:
        f.write(world_name)

    # zip as .mcworld
    mcworld = out_dir + ".mcworld"
    if os.path.exists(mcworld):
        os.remove(mcworld)
    with zipfile.ZipFile(mcworld, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, _dirs, files in os.walk(out_dir):
            for fn in files:
                full = os.path.join(root, fn)
                arc = os.path.relpath(full, out_dir)
                zf.write(full, arc)
    log(f"Bedrock: packaged -> {os.path.basename(mcworld)}")
    return mcworld


def _write_bedrock_level_dat(out_dir, world_name, spawn_xyz):
    sx, sy, sz = spawn_xyz
    c = L.Compound()
    c.set("LevelName", L.String(world_name))
    c.set("GameType", L.Int(1))
    c.set("Difficulty", L.Int(1))
    c.set("ForceGameType", L.Byte(0))
    c.set("SpawnX", L.Int(int(sx)))
    c.set("SpawnY", L.Int(int(sy)))
    c.set("SpawnZ", L.Int(int(sz)))
    c.set("Generator", L.Int(1))          # 1 = infinite
    c.set("commandsEnabled", L.Byte(1))
    c.set("StorageVersion", L.Int(9))
    c.set("NetworkVersion", L.Int(0))
    c.set("LastPlayed", L.Long(0))
    c.set("MinimumCompatibleClientVersion",
          L.List(L.TAG_INT, [L.Int(v) for v in (1, 18, 0, 0, 0)]))
    c.set("lastOpenedWithVersion",
          L.List(L.TAG_INT, [L.Int(v) for v in (1, 18, 30, 4, 0)]))
    c.set("InventoryVersion", L.String("1.18.30"))
    c.set("RandomSeed", L.Long(12345))
    c.set("spawnMobs", L.Byte(1))
    # Authorship — generated by MapSmith Free (Sandul Warnasooriya)
    c.set("Author", L.String("Sandul Warnasooriya"))
    c.set("Generator_Tool", L.String("MapSmith Free by Sandul Warnasooriya"))
    c.set("Daylight Cycle", L.Int(0))
    with open(os.path.join(out_dir, "level.dat"), "wb") as f:
        f.write(L.write_level_dat(c))
