"""EmptyChunk subclass that also writes Biomes and Entities.

The bundled anvil writer omits per-chunk biome data (so foliage/water render
with the default biome tint) and entities. This subclass injects both into the
1.16.5 "Level" NBT structure:

* ``Biomes``  — TAG_Int_Array of length 1024 (4x4x4 cells, 16x4x16 columns,
  64 vertical layers). We use a single horizontal 4x4 layer repeated for all
  64 height layers, which is what 1.16.5 expects.
* ``Entities`` — a list of entity compounds with Pos/Motion/etc.

Author: Sandul Warnasooriya
Built with: Arena.ai (https://arena.ai)
"""

from __future__ import annotations

from anvil import EmptyChunk
from nbt import nbt


class BiomeChunk(EmptyChunk):
    __slots__ = ("biomes", "entities")

    def __init__(self, x, z):
        super().__init__(x, z)
        # 4x4 horizontal biome cells for this chunk (default filled later)
        self.biomes = [1] * 16          # 4x4
        self.entities = []              # list of nbt.TAG_Compound

    def set_biome_cell(self, bx, bz, biome_id):
        """bx, bz in 0..3 (4x4 grid across the 16-wide chunk)."""
        self.biomes[bz * 4 + bx] = int(biome_id)

    def add_entity(self, tag):
        self.entities.append(tag)

    def save(self):
        root = super().save()
        level = root["Level"]

        # --- Biomes: 1024 ints (64 layers * 16 cells) ---
        full = []
        for _layer in range(64):
            full.extend(self.biomes)
        biomes_tag = nbt.TAG_Int_Array(name="Biomes")
        biomes_tag.value = full
        level.tags.append(biomes_tag)

        # --- Entities ---
        if self.entities:
            # replace the empty Entities list the parent created
            level.tags = [t for t in level.tags if t.name != "Entities"]
            ent_list = nbt.TAG_List(name="Entities", type=nbt.TAG_Compound)
            for e in self.entities:
                ent_list.tags.append(e)
            level.tags.append(ent_list)

        return root


def make_entity(eid: str, x: float, y: float, z: float, extra=None):
    """Build a minimal valid entity NBT compound for 1.16.5."""
    import uuid

    c = nbt.TAG_Compound()
    c.tags.append(nbt.TAG_String(name="id", value=eid))

    pos = nbt.TAG_List(name="Pos", type=nbt.TAG_Double)
    for v in (x + 0.5, y, z + 0.5):
        pos.tags.append(nbt.TAG_Double(value=v))
    c.tags.append(pos)

    motion = nbt.TAG_List(name="Motion", type=nbt.TAG_Double)
    for _ in range(3):
        motion.tags.append(nbt.TAG_Double(value=0.0))
    c.tags.append(motion)

    rot = nbt.TAG_List(name="Rotation", type=nbt.TAG_Float)
    rot.tags.append(nbt.TAG_Float(value=0.0))
    rot.tags.append(nbt.TAG_Float(value=0.0))
    c.tags.append(rot)

    # unique UUID (1.16 uses UUID int array)
    u = uuid.uuid4()
    ints = [
        (u.int >> 96) & 0xFFFFFFFF, (u.int >> 64) & 0xFFFFFFFF,
        (u.int >> 32) & 0xFFFFFFFF, u.int & 0xFFFFFFFF,
    ]
    ints = [v - 0x100000000 if v >= 0x80000000 else v for v in ints]
    uuid_tag = nbt.TAG_Int_Array(name="UUID")
    uuid_tag.value = ints
    c.tags.append(uuid_tag)

    c.tags.append(nbt.TAG_Short(name="Air", value=300))
    c.tags.append(nbt.TAG_Float(name="FallDistance", value=0.0))
    c.tags.append(nbt.TAG_Short(name="Fire", value=-1))
    c.tags.append(nbt.TAG_Byte(name="OnGround", value=1))
    c.tags.append(nbt.TAG_Byte(name="Invulnerable", value=0))
    c.tags.append(nbt.TAG_Byte(name="PersistenceRequired", value=1))

    if extra:
        for t in extra:
            c.tags.append(t)
    return c
