"""MapSmith Free — turn real-world map areas into Minecraft worlds.

A free, open, self-hosted alternative that converts OpenStreetMap data and
elevation into playable Minecraft Java worlds (with Bedrock conversion notes).

Author: Sandul Warnasooriya
Built with: Arena.ai (https://arena.ai)
"""

__version__ = "2.0.0"
__author__ = "Sandul Warnasooriya"
