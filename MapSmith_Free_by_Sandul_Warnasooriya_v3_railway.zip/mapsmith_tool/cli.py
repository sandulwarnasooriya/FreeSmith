"""MapSmith Free — command-line interface.

Examples
--------
Generate from an explicit bounding box (south west north east):

    python cli.py --bbox 7.000 80.600 7.0027 80.6027 --name "MyTown"

Generate from a centre point + radius in metres:

    python cli.py --center 7.0013 80.6013 --radius 400 --name "MyTown" --edition both

The finished world (folder + .zip) is written to ./output/.

Author: Sandul Warnasooriya
Built with: Arena.ai (https://arena.ai)
"""

from __future__ import annotations

import argparse
import math
import sys

from mapsmith.pipeline import generate


def center_radius_to_bbox(lat, lon, radius_m):
    R = 6378137.0
    dlat = (radius_m / R) * (180.0 / math.pi)
    dlon = (radius_m / (R * math.cos(math.radians(lat)))) * (180.0 / math.pi)
    return [lat - dlat, lon - dlon, lat + dlat, lon + dlon]


def main(argv=None):
    p = argparse.ArgumentParser(
        description="MapSmith Free by Sandul Warnasooriya — "
                    "OSM/elevation -> Minecraft world",
        epilog="Created by Sandul Warnasooriya.")
    g = p.add_mutually_exclusive_group(required=True)
    g.add_argument("--bbox", nargs=4, type=float, metavar=("S", "W", "N", "E"),
                   help="Bounding box: south west north east (degrees)")
    g.add_argument("--center", nargs=2, type=float, metavar=("LAT", "LON"),
                   help="Centre point; use with --radius")
    p.add_argument("--radius", type=float, default=400.0,
                   help="Radius in metres (with --center). Default 400.")
    p.add_argument("--spawn", nargs=2, type=float, metavar=("LAT", "LON"),
                   help="Spawn point lat lon (default: area centre)")
    p.add_argument("--name", default="MapSmith World", help="World name")
    p.add_argument("--edition", choices=["java", "bedrock", "both"], default="java")
    p.add_argument("--blocks-per-meter", type=float, default=1.0)
    p.add_argument("--vscale", type=float, default=1.0,
                   help="Terrain height exaggeration (1=realistic)")
    p.add_argument("--elev-samples", type=int, default=24,
                   help="Elevation grid resolution per side")
    p.add_argument("--theme", default="auto",
                   choices=["auto", "plains", "forest", "desert", "snowy",
                            "jungle", "savanna", "swamp"],
                   help="Biome theme (auto = guess from latitude)")
    p.add_argument("--no-mobs", action="store_true", help="Skip animals/villagers")
    p.add_argument("--no-structures", action="store_true",
                   help="Skip lamps/wells/stalls/etc.")
    p.add_argument("--preview-only", action="store_true",
                   help="Only render the 2D preview PNG (no world build)")
    args = p.parse_args(argv)

    if args.center:
        bbox = center_radius_to_bbox(args.center[0], args.center[1], args.radius)
    else:
        bbox = args.bbox

    spawn = tuple(args.spawn) if args.spawn else None

    res = generate(
        bbox_coords=bbox,
        spawn_latlon=spawn,
        world_name=args.name,
        edition=args.edition,
        blocks_per_meter=args.blocks_per_meter,
        vscale=args.vscale,
        elev_samples=args.elev_samples,
        theme=args.theme,
        add_mobs=not args.no_mobs,
        add_structures=not args.no_structures,
        preview_only=args.preview_only,
        log=lambda m: print(m, flush=True),
    )
    print("\n" + "=" * 50)
    print("DONE.")
    print("  Theme        :", res["theme"])
    print("  Size         :", f'{res["width"]} x {res["depth"]} blocks')
    print("  Spawn        :", res["spawn"])
    print("  Preview PNG  :", "static" + res["preview_url"].split("static")[-1])
    if not args.preview_only:
        print("  World folder :", res["world_dir"])
        print("  ZIP          :", res["zip_path"])
        print("  Structures   :", res.get("structures"))
        print("  Entities     :", res.get("entities"))
        if res.get("mcworld_path"):
            print("  Bedrock      :", res["mcworld_path"])
        if res.get("bedrock_note"):
            print("  Note         :", res["bedrock_note"])
    print("=" * 50)
    return 0


if __name__ == "__main__":
    sys.exit(main())
