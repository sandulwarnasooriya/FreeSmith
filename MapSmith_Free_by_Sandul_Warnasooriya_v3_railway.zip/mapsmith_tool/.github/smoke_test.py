"""Offline smoke test for CI — no network required.

Builds a tiny world from synthetic terrain + features and checks that:
  * the Java region writer produces a valid .mca + level.dat
  * the 2D and 3D previews render
  * the Bedrock (.mcworld) exporter runs (if LevelDB/plyvel is available)

by Sandul Warnasooriya · built with Arena.ai
"""

import os
import sys
import tempfile

import numpy as np

# Ensure repo root on path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from mapsmith.blocks import get_theme                       # noqa: E402
from mapsmith.terrain import LAND, BUILDING, ROAD, WATER    # noqa: E402
from mapsmith.worldbuilder import (                         # noqa: E402
    WorldBuilder, write_world, zip_world,
)
from mapsmith.preview import render_preview, render_iso_preview  # noqa: E402


def main():
    w = d = 48
    # synthetic heightmap: a gentle hill
    yy, xx = np.mgrid[0:d, 0:w]
    heights = ((np.sin(xx / 8.0) + np.cos(yy / 8.0)) * 6 + 12).astype(np.int32)

    surface = np.full((d, w), LAND, dtype=np.uint8)
    surface[10:14, :] = ROAD            # a road
    surface[20:30, 20:30] = BUILDING    # a building block
    surface[5:8, 5:8] = WATER           # a pond

    bld_h = np.zeros((d, w), dtype=np.uint8)
    bld_h[20:30, 20:30] = 8

    theme = get_theme("plains")

    with tempfile.TemporaryDirectory() as tmp:
        # build (capture voxels so we can also test Bedrock)
        wb = WorldBuilder(surface, heights, bld_h, (w // 2, d // 2), theme,
                          add_mobs=True, add_structures=True,
                          capture_voxels=True, log=lambda m: None)
        regions = wb.build()
        assert regions, "no regions produced"

        world_dir = os.path.join(tmp, "Smoke")
        write_world(regions, world_dir, "Smoke", (w // 2, d // 2), 80, log=lambda m: None)
        assert os.path.exists(os.path.join(world_dir, "level.dat")), "level.dat missing"
        mca = [f for f in os.listdir(os.path.join(world_dir, "region")) if f.endswith(".mca")]
        assert mca, "no .mca region files"

        zip_path = os.path.join(tmp, "Smoke.zip")
        zip_world(world_dir, zip_path, log=lambda m: None)
        assert os.path.getsize(zip_path) > 0, "empty zip"

        # previews
        p2d = os.path.join(tmp, "p.png")
        render_preview(surface, heights, "plains", (w // 2, d // 2), p2d)
        assert os.path.getsize(p2d) > 0, "2D preview empty"

        p3d = os.path.join(tmp, "p_iso.png")
        render_iso_preview(surface, heights, bld_h, "plains", (w // 2, d // 2), p3d)
        assert os.path.getsize(p3d) > 0, "3D preview empty"

        # Bedrock (optional — only if plyvel/LevelDB present)
        try:
            from mapsmith.bedrock import export_bedrock, HAVE_PLYVEL
            if HAVE_PLYVEL:
                br_dir = os.path.join(tmp, "Smoke_bedrock")
                mc = export_bedrock(wb.voxels, br_dir, "Smoke", (w // 2, 80, d // 2),
                                    log=lambda m: None)
                assert os.path.getsize(mc) > 0, "empty .mcworld"
                print("  Bedrock export: OK")
            else:
                print("  Bedrock export: skipped (plyvel unavailable)")
        except Exception as e:  # noqa: BLE001
            print(f"  Bedrock export: skipped ({e})")

    print("SMOKE TEST PASSED ✓ (Java world, level.dat, zip, 2D + 3D previews)")


if __name__ == "__main__":
    main()
