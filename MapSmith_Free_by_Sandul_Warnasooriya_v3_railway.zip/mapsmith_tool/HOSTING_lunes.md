# Running MapSmith Free on lunes.host (or any Pterodactyl panel)

by Sandul Warnasooriya · built with [Arena.ai](https://arena.ai)

Your panel (`node6.lunes.host:3075`) is a **Pterodactyl** game-server panel with
~**512 MiB RAM** and **512 MiB disk**. MapSmith runs there in **lite mode**,
which caps world size so it fits in memory (~214 MB peak).

> ⚠️ 512 MiB is tight. Lite mode (128 blocks/side ≈ 128 m × 128 m areas) works
> well. Bigger areas need a plan with more RAM — raise `MAPSMITH_MAX_BLOCKS`.

---

## What you need
A panel server (or "egg") that can run **Python 3.10+**. On lunes.host pick a
**Python** server type (or a generic/Docker "Python Generic" egg). A pure
Minecraft-only egg can't run Python.

---

## Option A — Upload the files (simplest)

1. In the panel, **stop** the server.
2. Open the **File Manager**.
3. Upload the project (either upload `MapSmith_Free_..._v3.zip` and use the
   panel's *Unarchive*, or drag the folder contents in).
   Make sure these are at the server root: `app.py`, `requirements.txt`,
   `start.sh`, `mapsmith/`, `templates/`, `static/`.
4. Go to **Startup** settings and set the **Startup Command** to:
   ```
   bash start.sh
   ```
   (If the egg uses a Python entrypoint instead, use:
   `pip install -r requirements.txt && python app.py`)
5. Make sure these **environment variables** are set (Startup tab):
   | Variable | Value | Why |
   |---|---|---|
   | `MAPSMITH_MAX_BLOCKS` | `128` | keeps RAM under 512 MiB |
   | `HOST` | `0.0.0.0` | listen on all interfaces |

   You usually **don't** set the port — the panel injects `SERVER_PORT`
   automatically (it's the `3075` you see). `start.sh` reads it.
6. **Start** the server. The console should show:
   ```
   Listening on http://0.0.0.0:3075
   Max world size: 128 blocks/side
   ```
7. Open **http://node6.lunes.host:3075** in your browser. 🎉

---

## Option B — Pull from GitHub (auto-update)

If your egg has `git`, set the startup command to clone/pull then run:
```
git pull || git clone https://github.com/<you>/mapsmith-free.git . ; bash start.sh
```

---

## Memory / disk tips for 512 MiB
- Keep `MAPSMITH_MAX_BLOCKS=128`. If you see the server killed/restarting, lower
  it to `96`.
- Disk is only 512 MiB: generated worlds are small (~100–300 KB each) but they
  pile up in `output/`. Periodically delete old files via the File Manager, or
  they're safe to clear anytime.
- Bedrock export needs LevelDB. Game panels often **lack** the system
  `libleveldb` library, so the Bedrock `.mcworld` may be skipped — the app
  **automatically falls back** to the Java `.zip` + the free converter note.
  Java export always works.

---

## Troubleshooting
- **"Address already in use"** — the panel already assigned the port; don't set
  `PORT` yourself, let `start.sh` use `SERVER_PORT`.
- **Page won't load** — confirm the console says `Listening on 0.0.0.0:<port>`
  and that you're using the panel's public address + that port.
- **Server keeps restarting / OOM** — lower `MAPSMITH_MAX_BLOCKS` to `96`.
- **No `pip`/`python`** — your server type isn't Python; switch the egg to a
  Python/Generic one.
