"""MapSmith Free — local web app.

Run:  python app.py
Then open http://127.0.0.1:5000 in your browser.

Draw an area on the map, set a spawn point, choose edition, click Generate,
and download a ready-to-play Minecraft world.

Author: Sandul Warnasooriya
Built with: Arena.ai (https://arena.ai)
"""

from __future__ import annotations

import os
import threading
import traceback
import uuid

from flask import (
    Flask, jsonify, render_template, request, send_file, abort,
)

from mapsmith.pipeline import OUTPUT_DIR, generate
from mapsmith import visitorlog

app = Flask(__name__)

# Optional token to protect the /admin/visitors view. Set MAPSMITH_ADMIN_TOKEN
# in the environment; if unset, the view is open (handy for private hosts).
ADMIN_TOKEN = os.environ.get("MAPSMITH_ADMIN_TOKEN", "")

# In-memory job registry: job_id -> {status, log[], result, error}
JOBS: dict[str, dict] = {}
JOBS_LOCK = threading.Lock()


def _new_job() -> str:
    jid = uuid.uuid4().hex[:12]
    with JOBS_LOCK:
        JOBS[jid] = {"status": "queued", "log": [], "result": None, "error": None}
    return jid


def _log(jid: str, msg: str) -> None:
    with JOBS_LOCK:
        JOBS[jid]["log"].append(str(msg))
    print(f"[{jid}] {msg}")


def _run(jid: str, params: dict) -> None:
    with JOBS_LOCK:
        JOBS[jid]["status"] = "running"
    try:
        result = generate(
            bbox_coords=params["bbox"],
            spawn_latlon=params.get("spawn"),
            world_name=params.get("name", "MapSmith World"),
            edition=params.get("edition", "java"),
            blocks_per_meter=params.get("blocks_per_meter", 1.0),
            vscale=params.get("vscale", 1.0),
            elev_samples=params.get("elev_samples", 24),
            theme=params.get("theme", "auto"),
            add_mobs=params.get("add_mobs", True),
            add_structures=params.get("add_structures", True),
            preview_only=params.get("preview_only", False),
            log=lambda m: _log(jid, m),
        )
        with JOBS_LOCK:
            JOBS[jid]["result"] = result
            JOBS[jid]["status"] = "done"
        _log(jid, "Generation complete.")
    except Exception as e:  # noqa: BLE001
        tb = traceback.format_exc()
        with JOBS_LOCK:
            JOBS[jid]["error"] = str(e)
            JOBS[jid]["status"] = "error"
        _log(jid, f"ERROR: {e}")
        _log(jid, tb)


@app.route("/")
def index():
    visitorlog.log_visit(request, action="visit")
    return render_template("index.html")


@app.route("/api/info")
def api_info():
    """Expose server limits so the UI can show the world-size cap."""
    from mapsmith.pipeline import MAX_BLOCKS
    return jsonify({"max_blocks": MAX_BLOCKS})


@app.route("/api/generate", methods=["POST"])
def api_generate():
    data = request.get_json(force=True)
    bbox = data.get("bbox")
    if not bbox or len(bbox) != 4:
        return jsonify({"error": "bbox required as [south, west, north, east]"}), 400

    # clamp area to something sane
    south, west, north, east = bbox
    if abs(north - south) > 0.05 or abs(east - west) > 0.05:
        return jsonify({"error": "Area too large. Keep each side under ~5 km."}), 400

    params = {
        "bbox": bbox,
        "spawn": tuple(data["spawn"]) if data.get("spawn") else None,
        "name": (data.get("name") or "MapSmith World")[:48],
        "edition": data.get("edition", "java"),
        "blocks_per_meter": float(data.get("blocks_per_meter", 1.0)),
        "vscale": float(data.get("vscale", 1.0)),
        "elev_samples": int(data.get("elev_samples", 24)),
        "theme": data.get("theme", "auto"),
        "add_mobs": bool(data.get("add_mobs", True)),
        "add_structures": bool(data.get("add_structures", True)),
        "preview_only": bool(data.get("preview_only", False)),
    }
    # Log genuine "generate" actions (skip preview-only renders).
    if not params["preview_only"]:
        visitorlog.log_visit(request, action="generate", extra={
            "world": params["name"], "edition": params["edition"],
            "theme": params["theme"],
        })

    jid = _new_job()
    threading.Thread(target=_run, args=(jid, params), daemon=True).start()
    return jsonify({"job_id": jid})


@app.route("/admin/visitors")
def admin_visitors():
    """View real (non-bot) visitors. Optionally protected by ?token=..."""
    if ADMIN_TOKEN and request.args.get("token", "") != ADMIN_TOKEN:
        return ("Unauthorized. Append ?token=YOUR_TOKEN to the URL "
                "(set via MAPSMITH_ADMIN_TOKEN)."), 401
    recs = visitorlog.read_recent(limit=300)
    stats = visitorlog.summary()
    if request.args.get("format") == "json":
        return jsonify({"stats": stats, "visitors": recs})
    return render_template("visitors.html", recs=recs, stats=stats)


@app.route("/api/status/<jid>")
def api_status(jid):
    with JOBS_LOCK:
        job = JOBS.get(jid)
        if not job:
            return jsonify({"error": "unknown job"}), 404
        return jsonify({
            "status": job["status"],
            "log": job["log"][-100:],
            "result": job["result"],
            "error": job["error"],
        })


@app.route("/api/download/<jid>")
def api_download(jid):
    with JOBS_LOCK:
        job = JOBS.get(jid)
    if not job or job["status"] != "done" or not job["result"]:
        abort(404)
    zip_path = job["result"].get("zip_path")
    if not zip_path or not os.path.exists(zip_path):
        abort(404)
    return send_file(zip_path, as_attachment=True,
                     download_name=job["result"]["zip_name"])


@app.route("/api/download_bedrock/<jid>")
def api_download_bedrock(jid):
    with JOBS_LOCK:
        job = JOBS.get(jid)
    if not job or job["status"] != "done" or not job["result"]:
        abort(404)
    path = job["result"].get("mcworld_path")
    if not path or not os.path.exists(path):
        abort(404)
    return send_file(path, as_attachment=True,
                     download_name=job["result"]["mcworld_name"])


if __name__ == "__main__":
    # Bind to the host-provided port (game panels / PaaS set $PORT or $SERVER_PORT)
    # and to all interfaces so it's reachable. Falls back to 5000 for local use.
    port = int(os.environ.get("PORT")
               or os.environ.get("SERVER_PORT")
               or 5000)
    host = os.environ.get("HOST", "0.0.0.0")
    print("=" * 60)
    print(" MapSmith Free  by Sandul Warnasooriya  ·  built with Arena.ai")
    print(f" Listening on http://{host}:{port}")
    print(" Output worlds saved to:", OUTPUT_DIR)
    from mapsmith.pipeline import MAX_BLOCKS
    print(f" Max world size: {MAX_BLOCKS} blocks/side "
          f"(set MAPSMITH_MAX_BLOCKS to change)")
    print("=" * 60)
    app.run(host=host, port=port, debug=False, threaded=True)
