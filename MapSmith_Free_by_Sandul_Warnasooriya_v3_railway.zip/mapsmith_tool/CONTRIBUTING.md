# Contributing to MapSmith Free

Thanks for your interest in improving MapSmith Free! 🎉
Created by Sandul Warnasooriya · built with [Arena.ai](https://arena.ai).

## Ways to help
- 🐛 Report bugs (open an Issue with steps + the area/coords you used)
- 💡 Suggest features
- 🌍 Add or improve biome themes / block palettes
- 🏗️ Improve world generation (interiors, structures, terrain)
- 📝 Improve docs

## Dev setup
```bash
git clone https://github.com/<you>/mapsmith-free.git
cd mapsmith-free
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
# For Bedrock export on Debian/Ubuntu:
sudo apt-get install libleveldb-dev libsnappy-dev
python app.py     # http://127.0.0.1:5000
```

## Project layout
- `mapsmith/` — core library (geo, datasources, terrain, blocks, worldbuilder,
  bedrock, preview, pipeline)
- `app.py` — Flask web app · `cli.py` — command line
- `templates/index.html` — web UI

## Guidelines
- Keep the tool **free and dependency-light**.
- Stick to blocks available in Minecraft 1.16.5 (the Java writer target).
- Run a quick generation before submitting a PR to make sure worlds still open.
- Be kind to the free public APIs (OpenStreetMap/Overpass, Open-Elevation);
  results are cached in `cache/`.

## Pull requests
1. Fork → create a branch → commit with clear messages.
2. Describe **what** changed and **why**, and include a preview screenshot if
   it affects generation.
3. Open the PR. 🙌
