# Deploying MapSmith Free 🚀

by Sandul Warnasooriya · built with [Arena.ai](https://arena.ai)

## Can I deploy it "via GitHub"?

**Yes — GitHub + a host, with auto-deploy on every push.**

Important: MapSmith has a **Python backend** (it downloads map data and builds
the world server-side). So **GitHub Pages will NOT work** — Pages only serves
static files and can't run Python.

Instead, the standard flow is:

```
  git push  ──►  GitHub  ──►  host (Render/Railway/Fly) auto-builds & deploys  ──►  public URL
```

You connect the host to your GitHub repo **once**; after that every push
redeploys automatically.

---

## Step 1 — Put the code on GitHub

```bash
# inside the mapsmith_tool folder (already a git repo)
git remote add origin https://github.com/<your-username>/mapsmith-free.git
git branch -M main
git push -u origin main
```

Once pushed, the included **GitHub Actions CI** (`.github/workflows/ci.yml`)
runs automatically and shows a green ✓ when the app builds and a test world
generates correctly.

---

## Step 2 — Deploy to a host (pick ONE)

### 🟢 Render.com — recommended, has a free tier
1. Go to [render.com](https://render.com) and sign in with GitHub.
2. **New → Blueprint** → select your `mapsmith-free` repo.
3. Render reads `render.yaml`, builds the `Dockerfile`, and deploys.
4. Your app is live at `https://<name>.onrender.com`.
5. Every future `git push` auto-redeploys. ✅

### 🟣 Railway
1. [railway.app](https://railway.app) → **New Project → Deploy from GitHub repo**.
2. Pick your repo. Railway auto-detects the `Dockerfile` and deploys.
3. Add a public domain in the service's **Settings → Networking**.

### 🔵 Fly.io — global edge, generous free allowance
```bash
# install flyctl: https://fly.io/docs/hands-on/install-flyctl/
fly auth login
fly launch --copy-config --no-deploy   # accept/edit the app name
fly deploy
```
Your app gets a `https://<name>.fly.dev` URL.

### ⚪ Any VPS / Docker host
```bash
git clone https://github.com/<your-username>/mapsmith-free.git
cd mapsmith-free
docker build -t mapsmith-free .
docker run -d -p 80:8000 --restart unless-stopped mapsmith-free
# now reachable on your server's IP / domain
```

---

## Important hosting notes ⚠️

- **Memory:** world generation peaks around **1 GB RAM**. Choose an instance
  with at least 1 GB. Free tiers handle small areas; big areas may need a paid
  plan.
- **Timeouts:** generation can take 10–60 s. The Docker/Procfile commands set a
  600 s gunicorn timeout already.
- **OpenStreetMap rate limits:** the free public Overpass API throttles heavy
  traffic. For a busy public site, either (a) add request throttling, or (b) run
  your own Overpass instance and point `OVERPASS_ENDPOINTS` at it
  (`mapsmith/datasources.py`).
- **Persistence:** generated worlds are stored on the instance's disk. On
  ephemeral hosts (Render free, Fly without a volume) they're wiped on restart —
  that's fine, since users download immediately. Attach a volume if you want to
  keep them.

---

## GitHub Pages alternative (frontend demo only)

If you only want to show the **map-picking UI** (no real world generation), you
could host just `templates/index.html` on GitHub Pages — but the "Build" button
would have nothing to call. For the full tool, use one of the hosts above.
